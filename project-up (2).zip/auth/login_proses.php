<?php
session_start();
include '../config/database.php';

/* =========================
   LOAD BAHASA (IKUT SESSION)
========================= */
$lang = $_SESSION['lang'] ?? 'id';

$langFile = __DIR__ . "/../lang/$lang.php";
$text = file_exists($langFile)
    ? include $langFile
    : include __DIR__ . "/../lang/id.php";

/* HELPER */
include '../helpers/lang.php';

/* =========================
   PROSES LOGIN
========================= */
$username = $_POST['username'];
$password = $_POST['password'];

$stmt = $conn->prepare("SELECT * FROM users WHERE username=?");
$stmt->bind_param("s", $username);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if ($data && password_verify($password, $data['password'])) {

    $_SESSION['login'] = true;
    $_SESSION['user']  = $data;

    /* LOADING SUCCESS */
    echo '
    <!doctype html>
    <html lang="'.$lang.'">
    <head>
        <meta charset="utf-8">
        <title>'.__('login_success').'</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            body{
                display:flex;
                justify-content:center;
                align-items:center;
                height:100vh;
                background:linear-gradient(135deg,#2563eb,#0dcaf0);
                font-family:Segoe UI,sans-serif;
            }
            .loader{
                width:70px;
                height:70px;
                border:8px solid rgba(255,255,255,.3);
                border-top:8px solid #fff;
                border-radius:50%;
                animation:spin 1s linear infinite;
            }
            @keyframes spin{
                0%{transform:rotate(0)}
                100%{transform:rotate(360deg)}
            }
            .text{
                margin-top:20px;
                color:#fff;
                font-weight:600;
            }
        </style>
    </head>
    <body>
        <div class="text-center">
            <div class="loader mx-auto"></div>
            <div class="text">'.__('login_success').', mohon tunggu...</div>
        </div>

        <script>
            setTimeout(()=>{
                window.location.href="../pages/dashboard.php";
            },1500);
        </script>
    </body>
    </html>';
    exit;

} else {

    /* ALERT GAGAL */
    echo '
    <!doctype html>
    <html lang="'.$lang.'">
    <head>
        <meta charset="utf-8">
        <title>'.__('login_failed').'</title>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    </head>
    <body>
        <script>
            Swal.fire({
                icon: "error",
                title: "'.__('login_failed').'",
                text: "'.__('login_failed').'",
                confirmButtonColor: "#2563eb",
                backdrop: true,
                allowOutsideClick: false
            }).then(() => {
                window.location = "login.php";
            });
        </script>
    </body>
    </html>';
}
