<?php
include '../config/database.php';

/* ==========================
   AJAX HANDLER
========================== */
if (isset($_GET['action'])) {
    header('Content-Type: application/json');

    /* ===== TAMBAH ===== */
    if ($_GET['action'] === 'tambah' && $_SERVER['REQUEST_METHOD'] === 'POST') {

        if (trim($_POST['nama']) === '') {
            echo json_encode([
                'status' => 'error',
                'message' => 'Nama finishing wajib diisi'
            ]);
            exit;
        }

        $stmt = $conn->prepare(
            "INSERT INTO finishing (nama_finishing, harga) VALUES (?,?)"
        );
        $stmt->bind_param("si", $_POST['nama'], $_POST['harga']);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Gagal menyimpan data'
            ]);
        }
        exit;
    }

    /* ===== EDIT ===== */
    if ($_GET['action'] === 'edit' && $_SERVER['REQUEST_METHOD'] === 'POST') {

        if (trim($_POST['nama']) === '') {
            echo json_encode([
                'status' => 'error',
                'message' => 'Nama finishing wajib diisi'
            ]);
            exit;
        }

        $stmt = $conn->prepare(
            "UPDATE finishing SET nama_finishing=?, harga=? WHERE id=?"
        );
        $stmt->bind_param(
            "sii",
            $_POST['nama'],
            $_POST['harga'],
            $_POST['id']
        );

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Gagal update data'
            ]);
        }
        exit;
    }

    /* ===== HAPUS ===== */
    if ($_GET['action'] === 'hapus' && $_SERVER['REQUEST_METHOD'] === 'POST') {

        $id = (int) $_POST['id'];

        $stmt = $conn->prepare("DELETE FROM finishing WHERE id=?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Data gagal dihapus (mungkin sedang digunakan)'
            ]);
        }
        exit;
    }
}

include '../inc/header.php';
include '../inc/sidebar.php';
?>

<div class="container-fluid fade-in">

  <div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0">
      <i class="fa-solid fa-layer-group me-2"></i> Finishing
    </h4>

    <button class="btn btn-primary btn-sm" id="btnTambah">
      <i class="fa fa-plus me-1"></i> Tambah Finishing
    </button>
  </div>

  <!-- TABLE -->
  <div class="card">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-striped align-middle">
          <thead>
            <tr class="text-center">
              <th width="50">No</th>
              <th>Nama Finishing</th>
              <th width="200">Harga</th>
              <th width="120">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $no = 1;
            $q = mysqli_query($conn, "SELECT * FROM finishing ORDER BY id DESC");
            while ($d = mysqli_fetch_assoc($q)):
            ?>
            <tr id="row-<?= $d['id'] ?>">
              <td class="text-center"><?= $no++ ?></td>
              <td class="nama fw-semibold">
                <?= htmlspecialchars($d['nama_finishing']) ?>
              </td>
              <td class="harga text-success fw-semibold">
                Rp <?= number_format($d['harga']) ?>
              </td>
              <td class="text-center">
                <button class="btn btn-warning btn-sm btn-edit"
                  data-id="<?= $d['id'] ?>"
                  data-nama="<?= htmlspecialchars($d['nama_finishing']) ?>"
                  data-harga="<?= $d['harga'] ?>">
                  <i class="fa fa-edit"></i>
                </button>
                <button class="btn btn-danger btn-sm btn-hapus"
                  data-id="<?= $d['id'] ?>">
                  <i class="fa fa-trash"></i>
                </button>
              </td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- MODAL -->
<div class="modal fade" id="formModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <form id="formData" class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title" id="modalTitle">Tambah Finishing</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <input type="hidden" name="id" id="edit_id">
        <input type="hidden" id="form_mode">

        <div class="mb-2">
          <label class="fw-semibold">Nama Finishing</label>
          <input type="text" name="nama" id="nama" class="form-control" required>
        </div>

        <div class="mb-2">
          <label class="fw-semibold">Harga</label>
          <input type="number" name="harga" id="harga" class="form-control" value="0">
        </div>
      </div>

      <div class="modal-footer">
        <button class="btn btn-primary w-100" type="submit">
          <i class="fa fa-save me-1"></i> Simpan
        </button>
      </div>

    </form>
  </div>
</div>

<?php include '../inc/footer.php'; ?>

<!-- SCRIPT -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(function () {

  const modal = new bootstrap.Modal(
    document.getElementById('formModal')
  );

  /* ===== TAMBAH ===== */
  $('#btnTambah').click(function () {
    $('#modalTitle').text('Tambah Finishing');
    $('#form_mode').val('tambah');
    $('#formData')[0].reset();
    $('#edit_id').val('');
    modal.show();
  });

  /* ===== EDIT ===== */
  $('.btn-edit').click(function () {
    $('#modalTitle').text('Edit Finishing');
    $('#form_mode').val('edit');
    $('#edit_id').val($(this).data('id'));
    $('#nama').val($(this).data('nama'));
    $('#harga').val($(this).data('harga'));
    modal.show();
  });

  /* ===== SIMPAN ===== */
  $('#formData').submit(function (e) {
    e.preventDefault();

    const mode = $('#form_mode').val();
    if (!mode) return;

    AppAlert.loading('Menyimpan...');

    $.ajax({
      url: '?action=' + mode,
      type: 'POST',
      data: $(this).serialize(),
      dataType: 'json',
      success(res) {
        if (res.status === 'success') {
          modal.hide();
          AppAlert.success('Data finishing tersimpan');
          setTimeout(() => location.reload(), 700);
        } else {
          Swal.fire('Gagal', res.message, 'error');
        }
      },
      error() {
        Swal.fire('Error', 'Server bermasalah', 'error');
      }
    });
  });

  /* ===== HAPUS ===== */
  $('.btn-hapus').click(function () {
    const id = $(this).data('id');

    AppAlert.confirmDelete('Data finishing tidak bisa dikembalikan')
      .then(result => {
        if (!result.isConfirmed) return;

        AppAlert.loading('Menghapus...');

        $.ajax({
          url: '?action=hapus',
          type: 'POST',
          data: { id },
          dataType: 'json',
          success(res) {
            if (res.status === 'success') {
              AppAlert.rowDeleteAnimation('row-' + id);
              AppAlert.success('Data berhasil dihapus', '', false);
            } else {
              Swal.fire('Gagal', res.message, 'error');
            }
          },
          error() {
            Swal.fire('Error', 'Server bermasalah', 'error');
          }
        });
      });
  });

});
</script>
