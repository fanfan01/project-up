<?php
include '../config/database.php';

/* ==========================
   RESPONSE HELPER
========================== */
function response($status,$message=''){
  echo json_encode([
    'status'=>$status,
    'message'=>$message
  ]);
  exit;
}

/* ==========================
   AJAX HANDLER
========================== */
if(isset($_GET['action'])){
  header('Content-Type: application/json');

  /* ===== TAMBAH ===== */
  if($_GET['action']==='tambah' && $_SERVER['REQUEST_METHOD']==='POST'){
    $nama = trim($_POST['nama'] ?? '');

    if($nama==='') response('error','Nama kategori kosong');

    $cek = $conn->prepare(
      "SELECT id FROM kategori WHERE nama=? LIMIT 1"
    );
    $cek->bind_param("s",$nama);
    $cek->execute();
    $cek->store_result();

    if($cek->num_rows>0){
      response('info','Kategori sudah ada');
    }

    $stmt = $conn->prepare(
      "INSERT INTO kategori (nama) VALUES (?)"
    );
    $stmt->bind_param("s",$nama);

    $stmt->execute()
      ? response('success','Kategori berhasil ditambahkan')
      : response('error','Gagal menyimpan data');
  }

  /* ===== EDIT ===== */
  if($_GET['action']==='edit' && $_SERVER['REQUEST_METHOD']==='POST'){
    $id   = intval($_POST['id'] ?? 0);
    $nama = trim($_POST['nama'] ?? '');

    if($id<=0 || $nama===''){
      response('error','Data tidak lengkap');
    }

    $stmt = $conn->prepare(
      "UPDATE kategori SET nama=? WHERE id=?"
    );
    $stmt->bind_param("si",$nama,$id);

    $stmt->execute()
      ? response('success','Kategori berhasil diubah')
      : response('error','Gagal update data');
  }

  /* ===== HAPUS ===== */
  if($_GET['action']==='hapus' && $_SERVER['REQUEST_METHOD']==='POST'){
    $id = intval($_POST['id'] ?? 0);

    if($id<=0){
      response('error','ID tidak valid');
    }

    $stmt = $conn->prepare(
      "DELETE FROM kategori WHERE id=?"
    );
    $stmt->bind_param("i",$id);

    $stmt->execute()
      ? response('success','Kategori berhasil dihapus')
      : response('error','Gagal menghapus data');
  }
}

include '../inc/header.php';
include '../inc/sidebar.php';
?>

<div class="container-fluid fade-in">

  <div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0">
      <i class="fa-solid fa-layer-group me-2"></i> Kategori
    </h4>
    <button class="btn btn-primary btn-sm" id="btnTambah">
      <i class="fa fa-plus me-1"></i> Tambah Kategori
    </button>
  </div>

  <div class="card">
    <div class="card-body">
      <table class="table table-striped align-middle">
        <thead>
          <tr class="text-center">
            <th width="60">No</th>
            <th>Nama Kategori</th>
            <th width="200">Tanggal</th>
            <th width="140">Aksi</th>
          </tr>
        </thead>
        <tbody>
        <?php
        $no=1;
        $q=mysqli_query(
          $conn,
          "SELECT * FROM kategori ORDER BY created_at DESC"
        );
        while($d=mysqli_fetch_assoc($q)):
        ?>
          <tr id="row-<?= $d['id'] ?>">
            <td class="text-center"><?= $no++ ?></td>
            <td class="fw-semibold"><?= htmlspecialchars($d['nama']) ?></td>
            <td class="text-center"><?= $d['created_at'] ?></td>
            <td class="text-center">
              <button class="btn btn-outline-warning btn-sm btn-edit"
                data-id="<?= $d['id'] ?>"
                data-nama="<?= htmlspecialchars($d['nama']) ?>">
                <i class="fa fa-edit"></i>
              </button>
              <button class="btn btn-outline-danger btn-sm btn-hapus"
                data-id="<?= $d['id'] ?>">
                <i class="fa fa-trash"></i>
              </button>
            </td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- MODAL -->
<div class="modal fade" id="formModal">
  <div class="modal-dialog modal-dialog-centered">
    <form id="formData" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalTitle"></h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="id">
        <label class="fw-semibold mb-1">Nama Kategori</label>
        <input type="text" id="nama" class="form-control" required>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary w-100">
          <i class="fa fa-save me-1"></i> Simpan
        </button>
      </div>
    </form>
  </div>
</div>

<?php include '../inc/footer.php'; ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(function(){

  let mode = '';
  const modal = new bootstrap.Modal(
    document.getElementById('formModal')
  );

  /* TAMBAH */
  $('#btnTambah').click(()=>{
    mode='tambah';
    $('#modalTitle').text('Tambah Kategori');
    $('#formData')[0].reset();
    $('#id').val('');
    modal.show();
  });

  /* EDIT */
  $(document).on('click','.btn-edit',function(){
    mode='edit';
    $('#modalTitle').text('Edit Kategori');
    $('#id').val($(this).data('id'));
    $('#nama').val($(this).data('nama'));
    modal.show();
  });

  /* SIMPAN */
  $('#formData').submit(function(e){
    e.preventDefault();

    AppAlert.loading('Menyimpan...');
    $.post('?action='+mode,{
      id: $('#id').val(),
      nama: $('#nama').val()
    },res=>{
      Swal.close();
      if(res.status==='success'){
        modal.hide();
        AppAlert.success(res.message);
        setTimeout(()=>location.reload(),500);
      }
      else if(res.status==='info'){
        AppAlert.info(res.message);
      }
      else{
        AppAlert.error(res.message);
      }
    },'json');
  });

  /* HAPUS */
  $(document).on('click','.btn-hapus',function(){
    const id = $(this).data('id');

    AppAlert.confirmDelete('Kategori akan dihapus permanen')
      .then(r=>{
        if(!r.isConfirmed) return;

        AppAlert.loading('Menghapus...');
        $.post('?action=hapus',{id},res=>{
          Swal.close();
          if(res.status==='success'){
            AppAlert.rowDeleteAnimation('row-'+id);
            AppAlert.success(res.message,'',false);
          }else{
            AppAlert.error(res.message);
          }
        },'json');
      });
  });

});
</script>
