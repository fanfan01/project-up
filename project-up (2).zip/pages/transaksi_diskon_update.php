<?php
include '../config/database.php';

$id     = (int)$_POST['id'];
$diskon = (int)$_POST['diskon'];

if ($id > 0) {
  mysqli_query($conn,"
    UPDATE transaksi 
    SET diskon='$diskon'
    WHERE id='$id'
  ");
}

echo json_encode(['status'=>'ok']);
