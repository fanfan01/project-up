<?php
include '../config/database.php';
include '../inc/header.php';
include '../inc/sidebar.php';

/* UPDATE STATUS (AMAN) */
if (isset($_GET['status'], $_GET['id'])) {

  $id = (int) $_GET['id'];

  // whitelist status yang boleh
  $allowedStatus = ['order','produksi','selesai','diambil'];
  $status = $_GET['status'];

  if (in_array($status, $allowedStatus)) {
    $stmt = mysqli_prepare(
      $conn,
      "UPDATE transaksi SET status=? WHERE id=?"
    );
    mysqli_stmt_bind_param($stmt, "si", $status, $id);
    mysqli_stmt_execute($stmt);
  }
}

?>

<div class="dashboard fade-in container-fluid">

  <!-- HEADER PAGE -->
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0">
      <i class="fa-solid fa-industry me-2"></i>
      Produksi
    </h4>
</div>

<div class="container-fluid">

<div class="card mb-4">


<!-- BODY -->
<div class="card-body">

<div class="table-responsive">
<table class="table table-striped align-middle">

<thead>
<tr class="text-center">
  <th width="50">No</th>
  <th>Kode</th>
  <th>Customer</th>
  <th>Tanggal</th>
  <th>Total</th>
  <th>Status</th>
  <th>Desain</th>
  <th width="220">Aksi</th>
</tr>
</thead>

<tbody>
<?php
$no=1;

$q = mysqli_query($conn,"
  SELECT 
    t.*,
    p.nama AS customer
  FROM transaksi t
  LEFT JOIN pelanggan p ON t.pelanggan_id = p.id
  ORDER BY t.id DESC
");

while($d=mysqli_fetch_assoc($q)){
?>
<tr>
  <td class="text-center"><?= $no++ ?></td>
  <td class="fw-semibold"><?= htmlspecialchars($d['kode']) ?></td>
  <td class="fw-semibold"><?= $d['customer'] ?: '-' ?></td>
  <td><?= date('d-m-Y H:i', strtotime($d['tanggal'])) ?></td>
  <td class="fw-semibold text-success">
    Rp <?= number_format($d['total']) ?>
  </td>
  <td class="text-center">
    <span class="badge bg-<?=
      $d['status']=='order'?'secondary':
      ($d['status']=='produksi'?'warning':
      ($d['status']=='selesai'?'success':'info'))
    ?>">
      <?= strtoupper($d['status']) ?>
    </span>
  </td>
    <td class="text-center">
      <?php if(!empty($d['file_desain'])){ ?>
        <a href="../upload/desain/<?= htmlspecialchars($d['file_desain']) ?>"
          class="btn btn-outline-success btn-sm"
          download="<?= htmlspecialchars($d['file_desain']) ?>">
          <i class="fa fa-download"></i>
        </a>
      <?php } else { echo '-'; } ?>
    </td>
  <td class="text-center">

    <?php if($d['status']=='order'){ ?>
      <a href="?id=<?= $d['id'] ?>&status=produksi"
         class="btn btn-warning btn-sm">
        Produksi
      </a>
    <?php } ?>

    <?php if($d['status']=='produksi'){ ?>
      <a href="?id=<?= $d['id'] ?>&status=selesai"
         class="btn btn-success btn-sm">
        Selesai
      </a>
    <?php } ?>

    <?php if($d['status']=='selesai'){ ?>
      <a href="?id=<?= $d['id'] ?>&status=diambil"
         class="btn btn-info btn-sm">
        Diambil
      </a>
    <?php } ?>

  </td>
</tr>
<?php } ?>
</tbody>

</table>
</div>

</div>
</div>
</div>

<?php include '../inc/footer.php'; ?>
