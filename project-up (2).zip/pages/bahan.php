<?php
include '../config/database.php';

/* ==========================
   AJAX HANDLER
========================== */
if (isset($_GET['action'])) {
  header('Content-Type: application/json');

  /* ===== TAMBAH ===== */
  if ($_GET['action'] === 'tambah' && $_SERVER['REQUEST_METHOD'] === 'POST') {

    $nama  = trim($_POST['nama'] ?? '');
    $harga = (int) ($_POST['harga'] ?? 0);

    if ($nama === '') {
      echo json_encode([
        'status' => 'error',
        'message' => 'Nama bahan wajib diisi'
      ]);
      exit;
    }

    $cek = $conn->prepare(
      "SELECT id FROM bahan WHERE nama_bahan=? LIMIT 1"
    );
    $cek->bind_param("s", $nama);
    $cek->execute();
    $cek->store_result();

    if ($cek->num_rows > 0) {
      echo json_encode([
        'status' => 'info',
        'message' => 'Bahan sudah ada'
      ]);
      exit;
    }

    $stmt = $conn->prepare(
      "INSERT INTO bahan (nama_bahan, tambahan_harga) VALUES (?,?)"
    );
    $stmt->bind_param("si", $nama, $harga);

    echo $stmt->execute()
      ? json_encode(['status' => 'success'])
      : json_encode(['status' => 'error','message'=>'Gagal menyimpan data']);
    exit;
  }

  /* ===== EDIT ===== */
  if ($_GET['action'] === 'edit' && $_SERVER['REQUEST_METHOD'] === 'POST') {

    $id    = (int) ($_POST['id'] ?? 0);
    $nama  = trim($_POST['nama'] ?? '');
    $harga = (int) ($_POST['harga'] ?? 0);

    if ($id <= 0 || $nama === '') {
      echo json_encode([
        'status' => 'error',
        'message' => 'Data tidak lengkap'
      ]);
      exit;
    }

    $stmt = $conn->prepare(
      "UPDATE bahan SET nama_bahan=?, tambahan_harga=? WHERE id=?"
    );
    $stmt->bind_param("sii", $nama, $harga, $id);

    echo $stmt->execute()
      ? json_encode(['status' => 'success'])
      : json_encode(['status' => 'error','message'=>'Gagal update data']);
    exit;
  }

  /* ===== HAPUS ===== */
  if ($_GET['action'] === 'hapus' && $_SERVER['REQUEST_METHOD'] === 'POST') {

    $id = (int) ($_POST['id'] ?? 0);

    if ($id <= 0) {
      echo json_encode([
        'status' => 'error',
        'message' => 'ID tidak valid'
      ]);
      exit;
    }

    $stmt = $conn->prepare(
      "DELETE FROM bahan WHERE id=?"
    );
    $stmt->bind_param("i", $id);

    echo $stmt->execute()
      ? json_encode(['status' => 'success'])
      : json_encode(['status' => 'error','message'=>'Gagal menghapus data']);
    exit;
  }
}

include '../inc/header.php';
include '../inc/sidebar.php';
?>

<div class="container-fluid fade-in">

  <div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0">
      <i class="fa-solid fa-cubes me-2"></i> Data Bahan
    </h4>

    <button type="button" class="btn btn-primary btn-sm" id="btnTambah">
      <i class="fa fa-plus me-1"></i> Tambah Bahan
    </button>
  </div>

  <!-- TABLE -->
  <div class="card">
    <div class="card-body table-responsive">
      <table class="table table-striped align-middle">
        <thead>
          <tr class="text-center">
            <th width="60">No</th>
            <th>Nama Bahan</th>
            <th width="220">Tambahan Harga</th>
            <th width="140">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $no = 1;
          $q = mysqli_query(
            $conn,
            "SELECT * FROM bahan ORDER BY nama_bahan ASC"
          );
          while ($d = mysqli_fetch_assoc($q)):
          ?>
          <tr id="row-<?= $d['id'] ?>">
            <td class="text-center"><?= $no++ ?></td>
            <td class="fw-semibold">
              <?= htmlspecialchars($d['nama_bahan']) ?>
            </td>
            <td class="text-center text-success fw-semibold">
              Rp <?= number_format($d['tambahan_harga'],0,',','.') ?>
            </td>
            <td class="text-center">
              <button type="button"
                class="btn btn-outline-warning btn-sm btn-edit"
                data-id="<?= $d['id'] ?>"
                data-nama="<?= htmlspecialchars($d['nama_bahan']) ?>"
                data-harga="<?= $d['tambahan_harga'] ?>">
                <i class="fa fa-edit"></i>
              </button>
              <button type="button"
                class="btn btn-outline-danger btn-sm btn-hapus"
                data-id="<?= $d['id'] ?>">
                <i class="fa fa-trash"></i>
              </button>
            </td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- MODAL -->
<div class="modal fade" id="formModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <form id="formData" class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title" id="modalTitle"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <input type="hidden" id="id">
        <input type="hidden" id="mode">

        <div class="mb-2">
          <label class="fw-semibold">Nama Bahan</label>
          <input type="text" id="nama" class="form-control" required>
        </div>

        <div class="mb-2">
          <label class="fw-semibold">Tambahan Harga</label>
          <input type="number" id="harga" class="form-control" value="0" min="0">
        </div>
      </div>

      <div class="modal-footer">
        <button type="submit" class="btn btn-primary w-100">
          <i class="fa fa-save me-1"></i> Simpan
        </button>
      </div>

    </form>
  </div>
</div>

<?php include '../inc/footer.php'; ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(function(){

  const modal = new bootstrap.Modal(
    document.getElementById('formModal')
  );

  /* ===== TAMBAH ===== */
  $(document).on('click','#btnTambah',function(){
    $('#modalTitle').text('Tambah Bahan');
    $('#mode').val('tambah');
    $('#formData')[0].reset();
    $('#id').val('');
    modal.show();
  });

  /* ===== EDIT ===== */
  $(document).on('click','.btn-edit',function(){
    $('#modalTitle').text('Edit Bahan');
    $('#mode').val('edit');
    $('#id').val($(this).data('id'));
    $('#nama').val($(this).data('nama'));
    $('#harga').val($(this).data('harga'));
    modal.show();
  });

  /* ===== SIMPAN ===== */
  $('#formData').submit(function(e){
    e.preventDefault();

    const mode = $('#mode').val();
    if(!mode) return;

    AppAlert.loading('Menyimpan...');

    $.post('?action='+mode,{
      id: $('#id').val(),
      nama: $('#nama').val(),
      harga: $('#harga').val()
    },res=>{
      Swal.close();
      if(res.status==='success'){
        modal.hide();
        AppAlert.success('Data bahan tersimpan');
        setTimeout(()=>location.reload(),600);
      }else if(res.status==='info'){
        AppAlert.info(res.message);
      }else{
        AppAlert.error(res.message);
      }
    },'json');
  });

  /* ===== HAPUS ===== */
  $(document).on('click','.btn-hapus',function(){
    const id = $(this).data('id');

    AppAlert.confirmDelete('Bahan akan dihapus permanen')
      .then(r=>{
        if(!r.isConfirmed) return;

        AppAlert.loading('Menghapus...');
        $.post('?action=hapus',{id},res=>{
          Swal.close();
          if(res.status==='success'){
            AppAlert.rowDeleteAnimation('row-'+id);
            AppAlert.success('Data berhasil dihapus','',false);
          }else{
            AppAlert.error(res.message);
          }
        },'json');
      });
  });

});
</script>

