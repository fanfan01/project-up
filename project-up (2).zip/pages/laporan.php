<?php
include '../config/database.php';
include '../inc/header.php';
include '../inc/sidebar.php';

/* FILTER */
$dari    = $_GET['dari'] ?? date('Y-m-01');
$sampai  = $_GET['sampai'] ?? date('Y-m-d');
$qSearch = $_GET['q'] ?? '';
?>

<div class="dashboard fade-in container-fluid">

  <!-- HEADER PAGE -->
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0">
      <i class="fa-solid fa-chart-line me-2"></i>
      Laporan
    </h4>
      <a href="laporan_print.php?dari=<?= $dari ?>&sampai=<?= $sampai ?>&q=<?= urlencode($qSearch) ?>"
        target="_blank"
        class="btn btn-outline-secondary btn-sm">
        <i class="fa-solid fa-file-invoice me-1"></i> Print
      </a>

  </div>

<div class="container-fluid">

<div class="card mb-4">

<div class="card-body">

<!-- FILTER FORM -->
<form method="GET" class="row g-3 mb-3 align-items-end">

  <div class="col-md-3">
    <label class="form-label fw-semibold">Tanggal Awal</label>
    <input type="date" name="dari" value="<?= $dari ?>" class="form-control" required>
  </div>

  <div class="col-md-3">
    <label class="form-label fw-semibold">Tanggal Akhir</label>
    <input type="date" name="sampai" value="<?= $sampai ?>" class="form-control" required>
  </div>

  <div class="col-md-3 position-relative">
    <label class="form-label fw-semibold">Pencarian</label>
    <input type="text" id="searchInput" name="q"
      class="form-control pe-5"
      placeholder="Kode / Customer / Status"
      value="<?= htmlspecialchars($qSearch) ?>">

    <!-- TOMBOL SILANG -->
    <button type="button" id="clearSearch"
      class="btn btn-sm btn-light position-absolute top-50 end-0 translate-middle-y me-2"
      style="display:none">✕</button>
  </div>

  <div class="col-md-3">
    <button class="btn btn-primary w-100">
      <i class="fa-solid fa-filter me-1"></i> Tampilkan
    </button>
  </div>

</form>

<?php if($qSearch){ ?>
  <p class="mb-2"><strong>Pencarian:</strong> <?= htmlspecialchars($qSearch) ?></p>
<?php } ?>

<!-- TABLE -->
<div class="table-responsive">
<table class="table table-striped align-middle" id="laporanTable">

<thead class="table-dark text-center">
<tr>
  <th>No</th>
  <th>Kode</th>
  <th>Tanggal</th>
  <th>Customer</th>
  <th>Status</th>
  <th>Total</th>
</tr>
</thead>

<tbody>

<?php
$no = 1;
$total_semua = 0;

$safeSearch = mysqli_real_escape_string($conn, $qSearch);

$sql = "
  SELECT 
    t.id,
    t.kode,
    t.tanggal,
    t.status,
    t.total,
    p.nama AS customer
  FROM transaksi t
  LEFT JOIN pelanggan p ON t.pelanggan_id = p.id
  WHERE t.tanggal >= '$dari 00:00:00'
    AND t.tanggal <= '$sampai 23:59:59'
";

if ($qSearch) {
  $sql .= "
    AND (
      t.kode LIKE '%$safeSearch%' OR
      p.nama LIKE '%$safeSearch%' OR
      t.status LIKE '%$safeSearch%'
    )
  ";
}

$sql .= " ORDER BY t.id DESC";

$q = mysqli_query($conn, $sql);
  if(mysqli_num_rows($q)){
  while($row=mysqli_fetch_assoc($q)){
    $total_semua += $row['total'];

    $badge = match($row['status']){
      'order'=>'secondary',
      'produksi'=>'warning',
      'selesai'=>'success',
      'diambil'=>'info',
      default=>'dark'
    };
?>
<tr>
  <td class="text-center"><?= $no++ ?></td>
  <td class="fw-semibold text-center"><?= htmlspecialchars($row['kode']) ?></td>
  <td class="text-center"><?= date('d-m-Y', strtotime($row['tanggal'])) ?></td>
  <td><?= htmlspecialchars($row['customer'] ?: '-') ?></td>
  <td class="text-center"><span class="badge bg-<?= $badge ?>"><?= strtoupper($row['status']) ?></span></td>
  <td class="text-end fw-semibold text-success">
    Rp <?= number_format($row['total'],0,',','.') ?>
  </td>
</tr>
<?php } } else { ?>
<tr>
  <td colspan="6" class="text-center text-muted py-4">Data tidak ditemukan</td>
</tr>
<?php } ?>
</tbody>

<tfoot>
<tr class="table-light">
  <th colspan="5" class="text-center">TOTAL</th>
  <th class="text-end fw-bold text-success">
    Rp <?= number_format($total_semua,0,',','.') ?>
  </th>
</tr>
</tfoot>

</table>
</div>

</div>
</div>
</div>

<!-- SCRIPT SEARCH + CLEAR -->
<script>
const searchInput = document.getElementById('searchInput');
const clearBtn = document.getElementById('clearSearch');

function toggleClear(){
  clearBtn.style.display = searchInput.value.trim() ? 'block' : 'none';
}
toggleClear();

/* FILTER TANPA RELOAD */
searchInput.addEventListener('input', () => {
  const f = searchInput.value.toLowerCase();
  document.querySelectorAll('#laporanTable tbody tr')
    .forEach(r => r.style.display = r.innerText.toLowerCase().includes(f) ? '' : 'none');
  toggleClear();
});

/* RESET SEARCH (TETAP PAKAI TANGGAL) */
clearBtn.addEventListener('click', () => {
  window.location.href =
    window.location.pathname + `?dari=<?= $dari ?>&sampai=<?= $sampai ?>`;
});
</script>

<?php include '../inc/footer.php'; ?>