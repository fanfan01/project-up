<?php
include '../config/database.php';

/* =====================================================
   AJAX HANDLER
===================================================== */
if (isset($_GET['action'])) {

  header('Content-Type: text/plain');

  /* TAMBAH */
  if ($_GET['action'] === 'tambah' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $conn->prepare(
      "INSERT INTO users (nama, username, password, role)
       VALUES (?, ?, ?, ?)"
    );

    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt->bind_param(
      "ssss",
      $_POST['nama'],
      $_POST['username'],
      $password,
      $_POST['role']
    );

    echo $stmt->execute() ? 'success' : 'error';
    exit;
  }

  /* EDIT */
  if ($_GET['action'] === 'edit' && $_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!empty($_POST['password'])) {
      $stmt = $conn->prepare(
        "UPDATE users SET nama=?, username=?, role=?, password=? WHERE id=?"
      );
      $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
      $stmt->bind_param(
        "ssssi",
        $_POST['nama'],
        $_POST['username'],
        $_POST['role'],
        $password,
        $_POST['edit_id']
      );
    } else {
      $stmt = $conn->prepare(
        "UPDATE users SET nama=?, username=?, role=? WHERE id=?"
      );
      $stmt->bind_param(
        "sssi",
        $_POST['nama'],
        $_POST['username'],
        $_POST['role'],
        $_POST['edit_id']
      );
    }

    echo $stmt->execute() ? 'success' : 'error';
    exit;
  }

  /* HAPUS */
  if ($_GET['action'] === 'hapus' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $conn->prepare("DELETE FROM users WHERE id=?");
    $stmt->bind_param("i", $id);
    echo $stmt->execute() ? 'success' : 'error';
    exit;
  }
}

include '../inc/header.php';
include '../inc/sidebar.php';
?>

<div class="container-fluid fade-in">

  <!-- HEADER -->
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0">
      <i class="fa fa-users me-2"></i> Pengguna
    </h4>

    <button class="btn btn-primary btn-sm" id="btnTambah">
      <i class="fa fa-plus me-1"></i> Tambah Pengguna
    </button>
  </div>

  <!-- CARD -->
  <div class="card">
    <div class="card-body">

      <div class="table-responsive">
        <table class="table table-striped align-middle">
          <thead class="table-dark">
            <tr>
              <th width="50">No</th>
              <th>Nama</th>
              <th>Username</th>
              <th width="120">Role</th>
              <th width="120">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $no = 1;
            $q = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC");
            while ($u = mysqli_fetch_assoc($q)) {
            ?>
              <tr id="row-<?= $u['id'] ?>">
                <td><?= $no++ ?></td>
                <td class="nama"><?= htmlspecialchars($u['nama']) ?></td>
                <td class="username"><?= htmlspecialchars($u['username']) ?></td>
                <td class="role"><?= $u['role'] ?></td>
                <td>
                  <button class="btn btn-outline-warning btn-sm btn-edit"
                    data-id="<?= $u['id'] ?>">
                    <i class="fa fa-edit"></i>
                  </button>
                  <button class="btn btn-outline-danger btn-sm btn-hapus"
                    data-id="<?= $u['id'] ?>">
                    <i class="fa fa-trash"></i>
                  </button>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>
</div>

<!-- MODAL -->
<div class="modal fade" id="userModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <form id="formUser" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalTitle">Tambah Pengguna</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <input type="hidden" name="edit_id" id="edit_id">
        <input type="hidden" id="form_mode">

        <div class="mb-2">
          <label>Nama</label>
          <input type="text" name="nama" id="nama" class="form-control" required>
        </div>

        <div class="mb-2">
          <label>Username</label>
          <input type="text" name="username" id="username" class="form-control" required>
        </div>

        <div class="mb-2">
          <label>Password</label>
          <input type="password" name="password" class="form-control">
          <small class="text-muted">Kosongkan jika tidak diubah</small>
        </div>

        <div class="mb-2">
          <label>Role</label>
          <select name="role" id="role" class="form-control" required>
            <option value="admin">Admin</option>
            <option value="kasir">Kasir</option>
          </select>
        </div>
      </div>

      <div class="modal-footer">
        <button class="btn btn-primary w-100">Simpan</button>
      </div>
    </form>
  </div>
</div>

<?php include '../inc/footer.php'; ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(function(){

/* ======================
   TAMBAH
====================== */
$('#btnTambah').on('click', function(){
  $('#modalTitle').text('Tambah Pengguna');
  $('#form_mode').val('tambah');
  $('#formUser')[0].reset();
  $('#edit_id').val('');
  $('#userModal').modal('show');
});

/* ======================
   EDIT
====================== */
$(document).on('click','.btn-edit',function(){
  const id  = $(this).data('id');
  const row = $('#row-'+id);

  $('#modalTitle').text('Edit Pengguna');
  $('#form_mode').val('edit');
  $('#edit_id').val(id);
  $('#nama').val(row.find('.nama').text().trim());
  $('#username').val(row.find('.username').text().trim());
  $('#role').val(row.find('.role').text().trim());

  $('#userModal').modal('show');
});

/* ======================
   SIMPAN
====================== */
$('#formUser').on('submit', function(e){
  e.preventDefault();

  const mode = $('#form_mode').val();
  if(!mode || typeof AppAlert === 'undefined') return;

  $.ajax({
    url:'?action='+mode,
    type:'POST',
    data:$(this).serialize(),
    beforeSend(){
      AppAlert.loading('Menyimpan...');
    },
    success(res){
      if(res.trim()==='success'){
        AppAlert.success('Data pengguna tersimpan');
      }else{
        AppAlert.error('Gagal menyimpan data');
      }
    },
    error(){
      AppAlert.error('Server error');
    }
  });
});

/* ======================
   HAPUS
====================== */
$(document).on('click','.btn-hapus',function(){
  const id = $(this).data('id');
  if(!id || typeof AppAlert === 'undefined') return;

  AppAlert.confirmDelete('Data pengguna tidak bisa dikembalikan')
    .then(r=>{
      if(!r.isConfirmed) return;

      $.ajax({
        url:'?action=hapus&id='+id,
        type:'POST',
        beforeSend(){
          AppAlert.loading('Menghapus...');
        },
        success(res){
          if(res.trim()==='success'){
            AppAlert.success('Data pengguna dihapus','',false);
            AppAlert.rowDeleteAnimation('row-'+id);
          }else{
            AppAlert.error('Gagal menghapus data');
          }
        }
      });
    });
});

});
</script>
