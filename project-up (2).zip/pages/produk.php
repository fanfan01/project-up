<?php
include '../config/database.php';

/* ==========================
   AMBIL KATEGORI
========================== */
$kategoriList = [];
$qKategori = mysqli_query(
  $conn,
  "SELECT id, nama FROM kategori ORDER BY nama ASC"
);
while($k = mysqli_fetch_assoc($qKategori)){
  $kategoriList[] = $k;
}

/* ==========================
   AJAX ACTION
========================== */
if(isset($_GET['action'])){
  header('Content-Type: application/json');

  // TAMBAH
  if($_GET['action']=='tambah' && $_SERVER['REQUEST_METHOD']=='POST'){
    $stmt = $conn->prepare(
      "INSERT INTO produk (nama_produk, kategori_id, harga_dasar)
       VALUES (?, ?, ?)"
    );
    $stmt->bind_param("sii",
      $_POST['nama'],
      $_POST['kategori_id'],
      $_POST['harga']
    );
    echo $stmt->execute()
      ? json_encode(['status'=>'success'])
      : json_encode(['status'=>'error']);
    exit;
  }

  // EDIT
  if($_GET['action']=='edit' && $_SERVER['REQUEST_METHOD']=='POST'){
    $stmt = $conn->prepare(
      "UPDATE produk
       SET nama_produk=?, kategori_id=?, harga_dasar=?
       WHERE id=?"
    );
    $stmt->bind_param("siii",
      $_POST['nama'],
      $_POST['kategori_id'],
      $_POST['harga'],
      $_POST['edit_id']
    );
    echo $stmt->execute()
      ? json_encode(['status'=>'success'])
      : json_encode(['status'=>'error']);
    exit;
  }

  // HAPUS
  if($_GET['action']=='hapus' && isset($_GET['id'])){
    $id = (int)$_GET['id'];
    $stmt = $conn->prepare("DELETE FROM produk WHERE id=?");
    $stmt->bind_param("i",$id);
    echo $stmt->execute()
      ? json_encode(['status'=>'success'])
      : json_encode(['status'=>'error']);
    exit;
  }
}

include '../inc/header.php';
include '../inc/sidebar.php';
?>

<div class="container-fluid fade-in">

  <div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0">
      <i class="fa-solid fa-box-open me-2"></i> Produk
    </h4>
    <button class="btn btn-primary btn-sm" id="btnTambah">
      <i class="fa fa-plus me-1"></i> Tambah Produk
    </button>
  </div>

  <div class="card">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-striped align-middle">
          <thead>
            <tr class="text-center">
              <th width="50">No</th>
              <th>Produk</th>
              <th width="160">Kategori</th>
              <th width="180">Harga</th>
              <th width="120">Aksi</th>
            </tr>
          </thead>
          <tbody>
          <?php
          $no = 1;
          $q = mysqli_query($conn,"
            SELECT p.*, k.nama AS kategori
            FROM produk p
            JOIN kategori k ON p.kategori_id = k.id
            ORDER BY p.id DESC
          ");
          while($d=mysqli_fetch_assoc($q)):
          ?>
            <tr id="row-<?= $d['id'] ?>">
              <td><?= $no++ ?></td>
              <td class="fw-semibold"><?= htmlspecialchars($d['nama_produk']) ?></td>
              <td><?= htmlspecialchars($d['kategori']) ?></td>
              <td class="fw-semibold text-success">
                Rp <?= number_format($d['harga_dasar']) ?>
              </td>
              <td class="text-center">
                <button class="btn btn-outline-warning btn-sm btn-edit"
                  data-id="<?= $d['id'] ?>"
                  data-nama="<?= htmlspecialchars($d['nama_produk']) ?>"
                  data-kategori="<?= $d['kategori_id'] ?>"
                  data-harga="<?= $d['harga_dasar'] ?>">
                  <i class="fa fa-edit"></i>
                </button>
                <button class="btn btn-outline-danger btn-sm btn-hapus"
                  data-id="<?= $d['id'] ?>">
                  <i class="fa fa-trash"></i>
                </button>
              </td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- MODAL -->
<div class="modal fade" id="produkModal">
  <div class="modal-dialog modal-dialog-centered">
    <form id="formProduk" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalTitle">Tambah Produk</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="edit_id" id="edit_id">
        <input type="hidden" id="form_mode">

        <div class="mb-2">
          <label class="fw-semibold">Nama Produk</label>
          <input type="text" name="nama" id="nama" class="form-control" required>
        </div>

        <div class="mb-2">
          <label class="fw-semibold">Kategori</label>
          <select name="kategori_id" id="kategori" class="form-control" required>
            <option value="">-- Pilih Kategori --</option>
            <?php foreach($kategoriList as $k): ?>
              <option value="<?= $k['id'] ?>">
                <?= ucfirst(htmlspecialchars($k['nama'])) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="mb-2">
          <label class="fw-semibold">Harga</label>
          <input type="number" name="harga" id="harga"
                 class="form-control" required>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary w-100">Simpan</button>
      </div>
    </form>
  </div>
</div>

<?php include '../inc/footer.php'; ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(function(){

  const modal = new bootstrap.Modal(
    document.getElementById('produkModal')
  );

  $('#btnTambah').click(()=>{
    $('#modalTitle').text('Tambah Produk');
    $('#form_mode').val('tambah');
    $('#formProduk')[0].reset();
    $('#edit_id').val('');
    modal.show();
  });

  $('.btn-edit').click(function(){
    const b = $(this);
    $('#modalTitle').text('Edit Produk');
    $('#form_mode').val('edit');
    $('#edit_id').val(b.data('id'));
    $('#nama').val(b.data('nama'));
    $('#kategori').val(b.data('kategori'));
    $('#harga').val(b.data('harga'));
    modal.show();
  });

  $('#formProduk').submit(function(e){
    e.preventDefault();
    const mode = $('#form_mode').val();

    AppAlert.loading('Menyimpan...');
    $.post('?action='+mode, $(this).serialize(), res=>{
      Swal.close();
      if(res.status==='success'){
        modal.hide();
        AppAlert.success('Data produk tersimpan');
        setTimeout(()=>location.reload(),500);
      } else {
        AppAlert.error('Gagal menyimpan data');
      }
    },'json');
  });

  $('.btn-hapus').click(function(){
    const id = $(this).data('id');
    AppAlert.confirmDelete('Data tidak bisa dikembalikan')
      .then(r=>{
        if(!r.isConfirmed) return;
        AppAlert.loading('Menghapus...');
        $.post('?action=hapus&id='+id, res=>{
          Swal.close();
          if(res.status==='success'){
            AppAlert.rowDeleteAnimation('row-'+id);
            AppAlert.success('Data dihapus','',false);
          } else {
            AppAlert.error('Gagal menghapus');
          }
        },'json');
      });
  });

});
</script>
