<?php
include '../config/database.php';

/* ==========================
   AJAX HANDLER
========================== */
if (isset($_GET['action'])) {

  header('Content-Type: application/json');

  /* ===== TAMBAH ===== */
  if ($_GET['action'] === 'tambah' && $_SERVER['REQUEST_METHOD'] === 'POST') {

    if (trim($_POST['nama']) === '') {
      echo json_encode([
        'status' => 'error',
        'message'=> 'Nama pelanggan wajib diisi'
      ]);
      exit;
    }

    $stmt = $conn->prepare(
      "INSERT INTO pelanggan (nama,no_hp,jenis) VALUES (?,?,?)"
    );
    $stmt->bind_param(
      "sss",
      $_POST['nama'],
      $_POST['no_hp'],
      $_POST['jenis']
    );

    if ($stmt->execute()) {
      echo json_encode(['status'=>'success']);
    } else {
      echo json_encode([
        'status'=>'error',
        'message'=>'Gagal menyimpan data'
      ]);
    }
    exit;
  }

  /* ===== EDIT ===== */
  if ($_GET['action'] === 'edit' && $_SERVER['REQUEST_METHOD'] === 'POST') {

    if (trim($_POST['nama']) === '') {
      echo json_encode([
        'status' => 'error',
        'message'=> 'Nama pelanggan wajib diisi'
      ]);
      exit;
    }

    $stmt = $conn->prepare(
      "UPDATE pelanggan SET nama=?, no_hp=?, jenis=? WHERE id=?"
    );
    $stmt->bind_param(
      "sssi",
      $_POST['nama'],
      $_POST['no_hp'],
      $_POST['jenis'],
      $_POST['id']
    );

    if ($stmt->execute()) {
      echo json_encode(['status'=>'success']);
    } else {
      echo json_encode([
        'status'=>'error',
        'message'=>'Gagal update data'
      ]);
    }
    exit;
  }

  /* ===== HAPUS ===== */
  if ($_GET['action'] === 'hapus' && $_SERVER['REQUEST_METHOD'] === 'POST') {

    $id = (int)$_POST['id'];

    $stmt = $conn->prepare("DELETE FROM pelanggan WHERE id=?");
    $stmt->bind_param("i",$id);

    if ($stmt->execute()) {
      echo json_encode(['status'=>'success']);
    } else {
      echo json_encode([
        'status'=>'error',
        'message'=>'Data gagal dihapus'
      ]);
    }
    exit;
  }
}

include '../inc/header.php';
include '../inc/sidebar.php';

/* ======================
   QUERY DATA
====================== */
$qPelanggan = mysqli_query($conn,"
  SELECT 
    p.*,
    COUNT(t.id) AS total_order,
    IFNULL(SUM(t.total),0) AS total_belanja
  FROM pelanggan p
  LEFT JOIN transaksi t ON t.pelanggan_id=p.id
  GROUP BY p.id
  ORDER BY p.id DESC
");
?>

<div class="container-fluid fade-in">

  <div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0">
    <i class="fa-solid fa-user-group me-2"></i> Data Pelanggan
  </h4>

  <button class="btn btn-primary btn-sm" id="btnTambah">
    <i class="fa fa-plus me-1"></i> Tambah Pelanggan
  </button>
      
  <script>
    window.onload = function() {
        document.getElementById("btnTambah").style.display = "none";
    }
</script>
      
</div>

  <div class="card">
    <div class="card-body">
      <table class="table table-striped align-middle">
        <thead>
<tr>
  <th>Nama</th>
  <th>No HP</th>
  <th>Jenis</th>
  <th>Order</th>
  <th>Total Belanja</th>
  <th width="160">Aksi</th>
</tr>
</thead>
<tbody>

<?php while($p=mysqli_fetch_assoc($qPelanggan)): ?>
<tr id="row-<?= $p['id'] ?>">
  <td class="fw-semibold"><?= htmlspecialchars($p['nama']) ?></td>
  <td><?= $p['no_hp'] ?: '-' ?></td>
  <td>
    <span class="badge bg-<?=
      $p['jenis']=='langganan'?'success':
      ($p['jenis']=='reseller'?'warning':'secondary')
    ?>">
      <?= ucfirst($p['jenis']) ?>
    </span>
  </td>
  <td><?= $p['total_order'] ?></td>
  <td>Rp <?= number_format($p['total_belanja'],0,',','.') ?></td>
  <td class="text-center">

    <button class="btn btn-outline-info btn-sm btn-histori"
      data-id="<?= $p['id'] ?>"
      data-nama="<?= htmlspecialchars($p['nama']) ?>">
      <i class="fa fa-clock"></i>
    </button>

    <button class="btn btn-outline-warning btn-sm btn-edit"
      data-id="<?= $p['id'] ?>"
      data-nama="<?= htmlspecialchars($p['nama']) ?>"
      data-nohp="<?= $p['no_hp'] ?>"
      data-jenis="<?= $p['jenis'] ?>">
      <i class="fa fa-edit"></i>
    </button>

    <button class="btn btn-outline-danger btn-sm btn-hapus"
      data-id="<?= $p['id'] ?>">
      <i class="fa fa-trash"></i>
    </button>

  </td>
</tr>
<?php endwhile; ?>

</tbody>
</table>
</div>

</div>
</div>
</div>

<!-- MODAL PELANGGAN -->
<div class="modal fade" id="modalPelanggan">
<div class="modal-dialog modal-dialog-centered">
<form id="formPelanggan" class="modal-content">

<div class="modal-header">
  <h5 class="modal-title" id="modalTitle">Tambah Pelanggan</h5>
  <button class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">
<input type="hidden" name="id" id="pelanggan_id">
<input type="hidden" id="form_mode">

<div class="mb-2">
  <label class="fw-semibold">Nama</label>
  <input type="text" name="nama" id="nama" class="form-control" required>
</div>

<div class="mb-2">
  <label class="fw-semibold">No HP</label>
  <input type="text" name="no_hp" id="no_hp" class="form-control">
</div>

<div class="mb-2">
  <label class="fw-semibold">Jenis</label>
  <select name="jenis" id="jenis" class="form-select">
    <option value="umum">Umum</option>
    <option value="langganan">Langganan</option>
    <option value="reseller">Reseller</option>
  </select>
</div>
</div>

<div class="modal-footer">
  <button type="submit" class="btn btn-primary w-100">
    <i class="fa fa-save me-1"></i> Simpan
  </button>
</div>

</form>
</div>
</div>

<!-- MODAL HISTORI -->
<div class="modal fade" id="modalHistori">
<div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
<div class="modal-content">
  <div class="modal-header">
    <h5 class="modal-title">Histori Pelanggan</h5>
    <button class="btn-close" data-bs-dismiss="modal"></button>
  </div>
  <div class="modal-body">
    <div id="historiContent">Memuat...</div>
  </div>
</div>
</div>
</div>

<?php include '../inc/footer.php'; ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(function(){

/* ===== TAMBAH ===== */
$('#btnTambah').click(()=>{
  $('#modalTitle').text('Tambah Pelanggan');
  $('#form_mode').val('tambah');
  $('#formPelanggan')[0].reset();
  $('#pelanggan_id').val('');
  $('#modalPelanggan').modal('show');
});

/* ===== EDIT ===== */
$('.btn-edit').click(function(){
  $('#modalTitle').text('Edit Pelanggan');
  $('#form_mode').val('edit');

  $('#pelanggan_id').val($(this).data('id'));
  $('#nama').val($(this).data('nama'));
  $('#no_hp').val($(this).data('nohp'));
  $('#jenis').val($(this).data('jenis'));

  $('#modalPelanggan').modal('show');
});

/* ===== SIMPAN ===== */
$('#formPelanggan').submit(function(e){
  e.preventDefault();

  const mode = $('#form_mode').val();
  if(!mode) return;

  AppAlert.loading('Menyimpan...');

  $.ajax({
    url:'?action='+mode,
    type:'POST',
    data:$(this).serialize(),
    dataType:'json',
    success(res){
      if(res.status==='success'){
        $('#modalPelanggan').modal('hide');
        AppAlert.success('Data pelanggan tersimpan');
        setTimeout(()=>location.reload(),700);
      }else{
        Swal.fire('Gagal',res.message,'error');
      }
    },
    error(){
      Swal.fire('Error','Server bermasalah','error');
    }
  });
});

/* ===== HAPUS ===== */
$('.btn-hapus').click(function(){
  const id=$(this).data('id');

  AppAlert.confirmDelete('Data pelanggan tidak bisa dikembalikan')
    .then(result=>{
      if(!result.isConfirmed) return;

      AppAlert.loading('Menghapus...');

      $.ajax({
        url:'?action=hapus',
        type:'POST',
        data:{id},
        dataType:'json',
        success(res){
          if(res.status==='success'){
            AppAlert.rowDeleteAnimation('row-'+id);
            AppAlert.success('Data berhasil dihapus','',false);
          }else{
            Swal.fire('Gagal',res.message,'error');
          }
        }
      });
    });
});

/* ===== HISTORI ===== */
$('.btn-histori').click(function(){
  const id=$(this).data('id');
  const nama=$(this).data('nama');

  $('#modalHistori .modal-title').text('Histori '+nama);
  $('#historiContent').html('Memuat...');
  $('#modalHistori').modal('show');

  $.get('pelanggan_histori.php',{id},res=>{
    $('#historiContent').html(res);
  }).fail(()=>{
    $('#historiContent').html('<div class="text-danger">Gagal memuat histori</div>');
  });
});

});
</script>
