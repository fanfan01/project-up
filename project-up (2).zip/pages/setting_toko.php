<?php
include '../config/database.php';

/* =====================================================
   AMBIL DATA SETTING TOKO
===================================================== */
$q = mysqli_query($conn, "SELECT * FROM setting_toko LIMIT 1");
$toko = mysqli_fetch_assoc($q);

if (!$toko) {
    mysqli_query($conn, "INSERT INTO setting_toko (nama_toko) VALUES ('Percetakan Pro')");
    $q = mysqli_query($conn, "SELECT * FROM setting_toko LIMIT 1");
    $toko = mysqli_fetch_assoc($q);
}

$id = $toko['id'];
$success = false;

/* =====================================================
   SIMPAN DATA
===================================================== */
if (isset($_POST['simpan'])) {

    $nama_toko = mysqli_real_escape_string($conn, $_POST['nama_toko']);
    $alamat    = mysqli_real_escape_string($conn, $_POST['alamat']);
    $no_hp     = mysqli_real_escape_string($conn, $_POST['no_hp']);
    $email     = mysqli_real_escape_string($conn, $_POST['email']);

    /* ================= LOGO UPLOAD ================= */
    $logo_name = $toko['logo'];

    if (!empty($_FILES['logo']['name'])) {

        $ext = strtolower(pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','webp'];

        if (in_array($ext, $allowed)) {

            $new_name = 'logo-' . time() . '.' . $ext;
            $upload_path = '../upload/logo/' . $new_name;

            if (move_uploaded_file($_FILES['logo']['tmp_name'], $upload_path)) {

                // hapus logo lama
                if (!empty($toko['logo']) && file_exists('../upload/logo/' . $toko['logo'])) {
                    unlink('../upload/logo/' . $toko['logo']);
                }

                $logo_name = $new_name;
            }
        }
    }

    /* ================= UPDATE DB ================= */
    mysqli_query($conn, "
        UPDATE setting_toko SET
            nama_toko = '$nama_toko',
            alamat    = '$alamat',
            no_hp     = '$no_hp',
            email     = '$email',
            logo      = '$logo_name'
        WHERE id = '$id'
    ");

    $success = true;

    $q = mysqli_query($conn, "SELECT * FROM setting_toko LIMIT 1");
    $toko = mysqli_fetch_assoc($q);
}

include '../inc/header.php';
include '../inc/sidebar.php';
?>

<div class="main-content fade-in container-fluid py-4">

  <!-- HEADER -->
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0">
      <i class="fa fa-cog me-2"></i>
      Setting Toko
    </h4>
  </div>

  <!-- CARD -->
  <div class="card dashboard-card">
    <div class="card-body p-4">

      <form method="post" enctype="multipart/form-data" autocomplete="off">

        <div class="row">
          <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Nama Toko</label>
            <input type="text" name="nama_toko" class="form-control"
                  value="<?= htmlspecialchars($toko['nama_toko']) ?>" required>
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">No. HP / WhatsApp</label>
            <input type="text" name="no_hp" class="form-control"
                  value="<?= htmlspecialchars($toko['no_hp']) ?>">
          </div>
        </div>

        <div class="mb-3">
          <label class="form-label fw-semibold">Alamat</label>
          <textarea name="alamat" rows="3"
                    class="form-control"><?= htmlspecialchars($toko['alamat']) ?></textarea>
        </div>

        <div class="row mb-4 align-items-top">

          <!-- EMAIL -->
          <div class="col-md-6">
            <label class="form-label fw-semibold">Email</label>
            <input type="email" name="email" class="form-control"
                  value="<?= htmlspecialchars($toko['email']) ?>">
          </div>

          <!-- LOGO -->
          <div class="col-md-6">
            <label class="form-label fw-semibold">Logo Toko</label>

            <div class="d-flex align-items-center gap-3">
              <img id="logoPreview"
                  src="<?= !empty($toko['logo']) ? '../upload/logo/'.$toko['logo'] : '' ?>"
                  class="shadow-sm"
                  style="
                    height:80px;
                    <?= empty($toko['logo']) ? 'display:none;' : '' ?>
                    border-radius:12px;
                    border:1px solid var(--border);
                  ">

              <div class="flex-grow-1">
                <input type="file" name="logo" class="form-control"
                      accept="image/*" onchange="previewLogo(this)">
                <small class="text-muted">JPG / PNG / WEBP • Max 2MB</small>
              </div>
            </div>
          </div>

        </div>

        <div class="d-flex justify-content-end">
          <button name="simpan" class="btn btn-primary px-4">
            <i class="fa fa-save me-1"></i> Simpan
          </button>
        </div>

      </form>

    </div>
  </div>

</div>

<?php include '../inc/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if ($success): ?>
<script>
Swal.fire({
  icon: 'success',
  title: 'Berhasil',
  text: 'Setting toko berhasil disimpan',
  timer: 1500,
  showConfirmButton: false
});
</script>
<?php endif; ?>

<script>
function previewLogo(input) {
  const preview = document.getElementById('logoPreview');
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = e => {
      preview.src = e.target.result;
      preview.style.display = 'block';
    };
    reader.readAsDataURL(input.files[0]);
  } else {
    preview.src = '';
    preview.style.display = 'none';
  }
}
</script>
