<?php
include '../config/database.php';

/* =====================
   MODE
===================== */
$mode = $_POST['mode'] ?? 'tambah';
$id_transaksi = (int)($_POST['id_transaksi'] ?? 0);

/* =====================
   AMBIL DATA
===================== */
$kode         = mysqli_real_escape_string($conn, $_POST['kode'] ?? '');
$pelanggan_id = (int)($_POST['customer'] ?? 0);

$produk_id    = (int)($_POST['produk'] ?? 0);
$bahan_id     = (int)($_POST['bahan'] ?? 0);
$finishing_id = (int)($_POST['finishing'] ?? 0);

$qty    = (int)($_POST['qty'] ?? 1);
$lebar  = (float)($_POST['lebar'] ?? 0);
$tinggi = (float)($_POST['tinggi'] ?? 0);
$diskon = (int)($_POST['diskon'] ?? 0);

/* =====================
   NORMALISASI FK
===================== */
$bahan_id     = $bahan_id ?: NULL;
$finishing_id = $finishing_id ?: NULL;

/* =====================
   UPLOAD FILE DESAIN
===================== */
$fileName = '';
if (!empty($_FILES['desain']['name'])) {

    $ext = strtolower(pathinfo($_FILES['desain']['name'], PATHINFO_EXTENSION));
    $fileName = $kode.'_'.time().'.'.$ext;

    if (!is_dir('../upload/desain')) {
        mkdir('../upload/desain', 0777, true);
    }

    move_uploaded_file(
        $_FILES['desain']['tmp_name'],
        '../upload/desain/'.$fileName
    );
}

/* =====================
   DATA PRODUK + KATEGORI
   (FIX BUG KATEGORI)
===================== */
$p = mysqli_fetch_assoc(
    mysqli_query($conn,"
        SELECT 
            p.harga_dasar,
            k.nama AS kategori
        FROM produk p
        LEFT JOIN kategori k ON k.id = p.kategori_id
        WHERE p.id = $produk_id
    ")
);

$harga = (int)($p['harga_dasar'] ?? 0);

/* =====================
   DATA BAHAN
===================== */
$hBahan = 0;
if ($bahan_id) {
    $b = mysqli_fetch_assoc(
        mysqli_query($conn,"SELECT tambahan_harga FROM bahan WHERE id=$bahan_id")
    );
    $hBahan = (int)($b['tambahan_harga'] ?? 0);
}

/* =====================
   DATA FINISHING
===================== */
$hFin = 0;
if ($finishing_id) {
    $f = mysqli_fetch_assoc(
        mysqli_query($conn,"SELECT harga FROM finishing WHERE id=$finishing_id")
    );
    $hFin = (int)($f['harga'] ?? 0);
}

/* =====================
   HITUNG TOTAL
===================== */
if (($p['kategori'] ?? '') === 'meter') {
    $subtotal = (($lebar * $tinggi * $harga) + $hBahan + $hFin) * $qty;
} else {
    $subtotal = ($harga + $hBahan + $hFin) * $qty;
}

$total = max(0, $subtotal - $diskon);

/* =====================
   SIMPAN / UPDATE
===================== */
if ($mode === 'edit' && $id_transaksi > 0) {

    /* UPDATE TRANSAKSI */
    $fileSql = $fileName ? ", file_desain='$fileName'" : "";

    mysqli_query($conn,"
        UPDATE transaksi SET
            pelanggan_id = $pelanggan_id,
            total        = $total,
            diskon       = $diskon
            $fileSql
        WHERE id = $id_transaksi
    ");

    /* UPDATE DETAIL */
    mysqli_query($conn,"
        UPDATE transaksi_detail SET
            produk_id    = $produk_id,
            lebar        = $lebar,
            tinggi       = $tinggi,
            qty          = $qty,
            bahan_id     = ".($bahan_id ? $bahan_id : "NULL").",
            finishing_id = ".($finishing_id ? $finishing_id : "NULL").",
            subtotal     = $subtotal
        WHERE transaksi_id = $id_transaksi
    ");

} else {

    /* INSERT TRANSAKSI */
    $fileField = $fileName ? "'$fileName'" : "NULL";

    mysqli_query($conn,"
        INSERT INTO transaksi (
            kode, tanggal, pelanggan_id,
            total, diskon, status, file_desain
        ) VALUES (
            '$kode', NOW(), $pelanggan_id,
            $total, $diskon, 'order', $fileField
        )
    ");

    $transaksi_id = mysqli_insert_id($conn);

    /* INSERT DETAIL */
    mysqli_query($conn,"
        INSERT INTO transaksi_detail (
            transaksi_id, produk_id,
            lebar, tinggi, qty,
            bahan_id, finishing_id, subtotal
        ) VALUES (
            $transaksi_id, $produk_id,
            $lebar, $tinggi, $qty,
            ".($bahan_id ? $bahan_id : "NULL").",
            ".($finishing_id ? $finishing_id : "NULL").",
            $subtotal
        )
    ");
}

echo "success";
exit;
