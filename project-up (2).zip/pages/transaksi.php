<?php
include '../config/database.php';


/* ==================================================
   AJAX TAMBAH CUSTOMER (KHUSUS TRANSAKSI)
================================================== */
if (isset($_GET['ajax']) && $_GET['ajax'] === 'customer') {

  header('Content-Type: application/json');

  if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status'=>'error','message'=>'Invalid request']);
    exit;
  }

  if (empty($_POST['nama'])) {
    echo json_encode(['status'=>'error','message'=>'Nama wajib diisi']);
    exit;
  }

  $stmt = $conn->prepare(
    "INSERT INTO pelanggan (nama,no_hp,jenis) VALUES (?,?,?)"
  );
  $stmt->bind_param(
    "sss",
    $_POST['nama'],
    $_POST['no_hp'],
    $_POST['jenis']
  );

  if ($stmt->execute()) {
    echo json_encode([
      'status' => 'success',
      'id'     => $conn->insert_id,
      'nama'   => $_POST['nama']
    ]);
  } else {
    echo json_encode(['status'=>'error','message'=>'Database error']);
  }
  exit;
}

include '../inc/header.php';
include '../inc/sidebar.php';

$kode = "ORD".date("ymdHis");

/* ======================
   DATA DROPDOWN
====================== */
$kategori  = mysqli_query($conn,"SELECT * FROM kategori ORDER BY nama ASC");
$produk    = mysqli_query($conn,"SELECT * FROM produk ORDER BY nama_produk ASC");
$bahan     = mysqli_query($conn,"SELECT * FROM bahan");
$finishing = mysqli_query($conn,"SELECT * FROM finishing");
$pelanggan = mysqli_query($conn,"SELECT * FROM pelanggan ORDER BY nama ASC");

?>

<div class="dashboard fade-in container-fluid">

<!-- HEADER -->
<div class="d-flex justify-content-between align-items-center mb-4">
  <h4 class="fw-bold mb-0">
    <i class="fa fa-receipt me-2"></i> Transaksi
  </h4>

  <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalTransaksi">
    <i class="fa fa-plus me-1"></i> Tambah Transaksi
  </button>
</div>

<div class="container-fluid px-0">
<div class="card mb-4">
<div class="card-body">

<div class="table-responsive">
<table class="table table-striped align-middle mb-0">
<thead class="table-light">
<tr class="text-center">
  <th>No</th>
  <th>Kode</th>
  <th>Customer</th>
  <th>Tanggal</th>
  <th>Produk</th>
  <th>Qty</th>
  <th>Bahan</th>
  <th>Finishing</th>
  <th>Total</th>
  <th width="120">Aksi</th>
</tr>
</thead>
<tbody>

<?php
$no=1;
$q=mysqli_query($conn,"
SELECT 
  t.id,
  t.kode,
  t.tanggal,
  t.total,
  pl.nama AS customer,
  p.nama_produk,
  d.qty,
  b.nama_bahan,
  f.nama_finishing
FROM transaksi t
LEFT JOIN pelanggan pl ON t.pelanggan_id=pl.id
LEFT JOIN transaksi_detail d ON d.transaksi_id=t.id
LEFT JOIN produk p ON p.id=d.produk_id
LEFT JOIN bahan b ON b.id=d.bahan_id
LEFT JOIN finishing f ON f.id=d.finishing_id
ORDER BY t.id DESC
");

while($d=mysqli_fetch_assoc($q)):
?>
<tr id="row-<?= $d['id'] ?>">
  <td class="text-center"><?= $no++ ?></td>
  <td><?= htmlspecialchars($d['kode']) ?></td>
  <td class="fw-semibold"><?= $d['customer'] ?: '-' ?></td>
  <td><?= date('d/m/Y H:i',strtotime($d['tanggal'])) ?></td>
  <td><?= $d['nama_produk'] ?: '-' ?></td>
  <td class="text-center"><?= $d['qty'] ?: '-' ?></td>
  <td><?= $d['nama_bahan'] ?: '-' ?></td>
  <td><?= $d['nama_finishing'] ?: '-' ?></td>
  <td class="fw-bold text-success">
    Rp <?= number_format($d['total'],0,',','.') ?>
  </td>
  <td class="text-center">
    <div class="btn-group btn-group-sm">
      <button class="btn btn-outline-warning btn-edit" data-id="<?= $d['id'] ?>">
        <i class="fa fa-edit"></i>
      </button>
      <button class="btn btn-outline-danger btn-hapus" data-id="<?= $d['id'] ?>">
        <i class="fa fa-trash"></i>
      </button>
    </div>
  </td>
</tr>
<?php endwhile; ?>

</tbody>
</table>
</div>

</div>
</div>
</div>
</div>

<!-- =========================
   MODAL TRANSAKSI
========================= -->
<div class="modal fade" id="modalTransaksi">
<div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
<form id="formTransaksi" class="modal-content" enctype="multipart/form-data">

<input type="hidden" name="mode" id="form_mode" value="tambah">
<input type="hidden" name="id_transaksi" id="id_transaksi">
<input type="hidden" name="kode" value="<?= $kode ?>">

<div class="modal-header">
  <h5 class="modal-title">
    <i class="fa fa-plus me-2"></i> Tambah Transaksi
  </h5>
  <button class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">
<div class="row g-3">

<div class="col-md-6">
  <label class="fw-semibold d-flex justify-content-between">
    Customer
    <a href="#" id="btnTambahCustomer">+ Tambah</a>
  </label>
  <select name="customer" id="selectCustomer" class="form-select" required>
    <option value="">Pilih Customer</option>
    <?php while($c=mysqli_fetch_assoc($pelanggan)): ?>
      <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nama']) ?></option>
    <?php endwhile; ?>
  </select>
</div>

<div class="col-md-6">
  <label class="fw-semibold">Produk</label>
  <select name="produk" id="selectProduk" class="form-select" required>
    <option value="">Pilih Produk</option>
    <?php while($p=mysqli_fetch_assoc($produk)): ?>
      <option value="<?= $p['id'] ?>"><?= $p['nama_produk'] ?></option>
    <?php endwhile; ?>
  </select>
</div>

<div class="col-md-4">
  <label>Qty</label>
  <input type="number" name="qty" class="form-control" required>
</div>

<div class="col-md-4">
  <label>Lebar</label>
  <input type="number" step="0.01" name="lebar" class="form-control">
</div>

<div class="col-md-4">
  <label>Tinggi</label>
  <input type="number" step="0.01" name="tinggi" class="form-control">
</div>

<div class="col-md-6">
  <label>Bahan</label>
  <select name="bahan" class="form-select">
    <option value="0">Tanpa Bahan</option>
    <?php mysqli_data_seek($bahan,0); while($b=mysqli_fetch_assoc($bahan)): ?>
      <option value="<?= $b['id'] ?>"><?= $b['nama_bahan'] ?></option>
    <?php endwhile; ?>
  </select>
</div>

<div class="col-md-6">
  <label>Finishing</label>
  <select name="finishing" class="form-select">
    <option value="0">Tanpa Finishing</option>
    <?php mysqli_data_seek($finishing,0); while($f=mysqli_fetch_assoc($finishing)): ?>
      <option value="<?= $f['id'] ?>"><?= $f['nama_finishing'] ?></option>
    <?php endwhile; ?>
  </select>
</div>

<div class="col-md-12">
  <label>File Desain</label>
  <input type="file" name="desain" class="form-control">
</div>

</div>
</div>

<div class="modal-footer">
  <button class="btn btn-primary w-100">
    <i class="fa fa-save me-1"></i> Simpan Transaksi
  </button>
</div>

</form>
</div>
</div>

<!-- =========================
   MODAL TAMBAH CUSTOMER
========================= -->
<div class="modal fade" id="modalCustomer">
<div class="modal-dialog modal-dialog-centered">
<form id="formCustomer" class="modal-content">

<div class="modal-header">
  <h5 class="modal-title">
    <i class="fa fa-user-plus me-2"></i> Tambah Customer
  </h5>
  <button class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">

<div class="mb-2">
  <label class="fw-semibold">Nama</label>
  <input type="text" name="nama" class="form-control" required>
</div>

<div class="mb-2">
  <label class="fw-semibold">No HP</label>
  <input type="text" name="no_hp" class="form-control">
</div>

<div class="mb-2">
  <label class="fw-semibold">Jenis</label>
  <select name="jenis" class="form-select" required>
    <option value="umum">Umum</option>
    <option value="langganan">Langganan</option>
    <option value="reseller">Reseller</option>
  </select>
</div>

</div>

<div class="modal-footer">
  <button type="submit" class="btn btn-primary w-100">
    <i class="fa fa-save me-1"></i> Simpan
  </button>
</div>

</form>
</div>
</div>

<?php include '../inc/footer.php'; ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
$(function(){

/* =====================
   INIT SELECT2 (GLOBAL)
===================== */
function initSelect2(){

  // CUSTOMER
  if ($('#selectCustomer').length){
    if ($('#selectCustomer').hasClass('select2-hidden-accessible')) {
      $('#selectCustomer').select2('destroy');
    }

    $('#selectCustomer').select2({
      dropdownParent: $('#modalTransaksi'),
      placeholder: 'Pilih atau ketik nama customer',
      width: '100%'
    });
  }

  // PRODUK
  if ($('#selectProduk').length){
    if ($('#selectProduk').hasClass('select2-hidden-accessible')) {
      $('#selectProduk').select2('destroy');
    }

    $('#selectProduk').select2({
      dropdownParent: $('#modalTransaksi'),
      placeholder: 'Pilih produk',
      width: '100%'
    });
  }
}

/* =====================
   SAAT MODAL TRANSAKSI DIBUKA
===================== */
$('#modalTransaksi').on('shown.bs.modal', function () {
  initSelect2();
});


/* =====================
   SIMPAN TRANSAKSI
===================== */
$('#formTransaksi').on('submit', function(e){
  e.preventDefault();

  const data = new FormData(this);
  AppAlert.loading('Menyimpan transaksi...');

  $.ajax({
    url: 'transaksi_simpan.php',
    type: 'POST',
    data: data,
    contentType: false,
    processData: false,
    success(res){
      if(res.trim() === 'success'){
        AppAlert.success('Berhasil','Transaksi tersimpan');
      }else{
        Swal.fire('Gagal', res, 'error');
      }
    },
    error(){
      Swal.fire('Error','Server bermasalah','error');
    }
  });
});


/* =====================
   EDIT TRANSAKSI
===================== */
$(document).on('click','.btn-edit',function(){
  const id = $(this).data('id');

  AppAlert.loading('Memuat data...');

  $.getJSON('transaksi_get.php',{id:id},function(d){
    Swal.close();

    if(d.error){
      Swal.fire('Error',d.error,'error');
      return;
    }

    $('#form_mode').val('edit');
    $('#id_transaksi').val(id);

    $('#modalTransaksi').modal('show');

    // tunggu modal tampil baru set value
    setTimeout(() => {
      $('#selectCustomer').val(d.pelanggan_id).trigger('change');
      $('#selectProduk').val(d.produk_id).trigger('change');
    }, 200);

    $('[name=qty]').val(d.qty);
    $('[name=lebar]').val(d.lebar);
    $('[name=tinggi]').val(d.tinggi);
    $('[name=bahan]').val(d.bahan_id);
    $('[name=finishing]').val(d.finishing_id);

    $('#modalTransaksi .modal-title')
      .html('<i class="fa fa-edit me-2"></i> Edit Transaksi');
  });
});


/* =====================
   HAPUS TRANSAKSI
===================== */
$(document).on('click','.btn-hapus',function(){
  const id = $(this).data('id');

  AppAlert.confirmDelete('Transaksi akan dihapus').then(result=>{
    if(!result.isConfirmed) return;

    AppAlert.loading('Menghapus...');

    $.post('transaksi_hapus.php',{id:id},function(r){
      if(r.trim()==='success'){
        AppAlert.rowDeleteAnimation('row-'+id);
        Swal.fire({
          icon:'success',
          title:'Dihapus',
          timer:1000,
          showConfirmButton:false
        });
      }else{
        Swal.fire('Gagal',r,'error');
      }
    });
  });
});


/* =====================
   TAMBAH CUSTOMER (MODAL)
===================== */
$('#btnTambahCustomer').on('click',function(e){
  e.preventDefault();
  $('#modalTransaksi').modal('hide');

  setTimeout(()=>{
    $('#modalCustomer').modal('show');
  },300);
});


/* =====================
   SIMPAN CUSTOMER
===================== */
$('#formCustomer').on('submit',function(e){
  e.preventDefault();

  AppAlert.loading('Menyimpan customer...');

  $.ajax({
    url:'transaksi.php?ajax=customer',
    type:'POST',
    data:$(this).serialize(),
    dataType:'json',
    success(res){
      if(res.status === 'success'){

        const option = new Option(res.nama, res.id, true, true);
        $('#selectCustomer').append(option).trigger('change');

        Swal.fire({
          icon:'success',
          title:'Customer ditambahkan',
          timer:900,
          showConfirmButton:false
        });

        $('#formCustomer')[0].reset();
        $('#modalCustomer').modal('hide');

        setTimeout(()=>{
          $('#modalTransaksi').modal('show');
        },300);

      }else{
        Swal.fire('Gagal',res.message,'error');
      }
    },
    error(){
      Swal.fire('Error','Server bermasalah','error');
    }
  });
});

});
</script>
