<?php
ob_clean();
include '../config/database.php';
header('Content-Type: application/json');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
  echo json_encode(['error' => 'ID tidak valid']);
  exit;
}

$stmt = $conn->prepare("
  SELECT 
    t.id,
    t.pelanggan_id,
    d.produk_id,
    d.qty,
    d.lebar,
    d.tinggi,
    d.bahan_id,
    d.finishing_id
  FROM transaksi t
  JOIN transaksi_detail d ON t.id = d.transaksi_id
  WHERE t.id = ?
  LIMIT 1
");

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();
$data = $result->fetch_assoc();

if (!$data) {
  echo json_encode(['error' => 'Data tidak ditemukan']);
  exit;
}

echo json_encode($data);
exit;
