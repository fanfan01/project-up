<?php
include '../config/database.php';

$id = $_GET['id'] ?? '';
$data = ['nama'=>'','no_hp'=>'','jenis'=>'umum'];

if($id){
  $q = mysqli_query($conn,"SELECT * FROM pelanggan WHERE id=$id");
  $data = mysqli_fetch_assoc($q);
}

if($_POST){
  $nama = $_POST['nama'];
  $no_hp = $_POST['no_hp'];
  $jenis = $_POST['jenis'];

  if($id){
    mysqli_query($conn,"
      UPDATE pelanggan SET
      nama='$nama', no_hp='$no_hp', jenis='$jenis'
      WHERE id=$id
    ");
  }else{
    mysqli_query($conn,"
      INSERT INTO pelanggan (nama,no_hp,jenis)
      VALUES ('$nama','$no_hp','$jenis')
    ");
  }

  header("Location: pelanggan.php");
}
?>

<h4><?= $id?'Edit':'Tambah' ?> Pelanggan</h4>

<form method="post">
  <div class="mb-2">
    <label>Nama</label>
    <input type="text" name="nama" class="form-control" required value="<?= $data['nama'] ?>">
  </div>

  <div class="mb-2">
    <label>No HP</label>
    <input type="text" name="no_hp" class="form-control" value="<?= $data['no_hp'] ?>">
  </div>

  <div class="mb-2">
    <label>Jenis</label>
    <select name="jenis" class="form-control">
      <option value="umum" <?= $data['jenis']=='umum'?'selected':'' ?>>Umum</option>
      <option value="langganan" <?= $data['jenis']=='langganan'?'selected':'' ?>>Langganan</option>
      <option value="reseller" <?= $data['jenis']=='reseller'?'selected':'' ?>>Reseller</option>
    </select>
  </div>

  <button class="btn btn-primary">Simpan</button>
  <a href="pelanggan.php" class="btn btn-secondary">Kembali</a>
</form>
