<?php
include_once __DIR__ . '/../config/database.php';

$toko = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT * FROM setting_toko LIMIT 1")
) ?? [];

$nama_toko = $toko['nama_toko'] ?? 'Percetakan Pro';
$alamat    = $toko['alamat'] ?? '';
?>

    </div> <!-- /row -->
  </div> <!-- /container-fluid -->
</main> <!-- /MAIN -->

<footer class="footer">
  <div class="container-fluid text-center">
    <small class="text-muted">
      &copy; <?= date('Y') ?> <?= htmlspecialchars($nama_toko) ?>
      <?php if ($alamat): ?>
        <span class="opacity-50 mx-1">•</span>
        <?= htmlspecialchars($alamat) ?>
      <?php endif; ?>
    </small>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/theme.js"></script>
</body>
</html>
