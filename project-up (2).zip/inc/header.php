<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* =========================
   LOAD BAHASA
========================= */
$lang = $_SESSION['lang'] ?? 'id';

$langFile = __DIR__ . "/../lang/$lang.php";
$text = file_exists($langFile)
    ? include $langFile
    : include __DIR__ . "/../lang/id.php";

/* =========================
   DATABASE
========================= */
include '../config/database.php';

/* =========================
   HELPERS
========================= */
include '../helpers/lang.php';

/* =========================
   AMBIL NAMA TOKO
========================= */
$toko = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT * FROM setting_toko LIMIT 1")
);

$nama_toko = $toko['nama_toko'] ?? 'Percetakan Pro';
$logo_toko = $toko['logo'] ?? null;

/* =========================
   AMBIL DATA USER (AMAN)
========================= */
$userNama = null;
$userRole = null;

if (!empty($_SESSION['user'])) {
    $userNama = $_SESSION['user']['nama']
        ?? $_SESSION['user']['username']
        ?? 'Administrator';
    $userRole = strtolower($_SESSION['user']['role'] ?? 'user');
} elseif (!empty($_SESSION['nama'])) {
    $userNama = $_SESSION['nama'];
    $userRole = strtolower($_SESSION['role'] ?? 'user');
}
?>
<!DOCTYPE html>
<html lang="<?= $_SESSION['lang'] ?? 'id' ?>">
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- 🔥 ANTI FLICKER DARK MODE -->
<script>
(function () {
  try {
    if (localStorage.getItem('darkmode') === 'true') {
      document.documentElement.classList.add('dark');
    }
  } catch (e) {}
})();
</script>

<title><?= htmlspecialchars($nama_toko) ?></title>

<?php if (!empty($toko['logo']) && file_exists('../upload/logo/' . $toko['logo'])): ?>
<link rel="icon"
      href="../upload/logo/<?= htmlspecialchars($toko['logo']) ?>?v=<?= filemtime('../upload/logo/' . $toko['logo']) ?>">
<?php endif; ?>

<!-- Bootstrap & FontAwesome -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

<!-- SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- Custom CSS -->
<link href="../assets/css/theme.css" rel="stylesheet">

</head>

<body class="d-flex flex-column min-vh-100">
<!-- =========================
     NAVBAR
========================= -->
<nav class="navbar navbar-custom mb-3 px-3">

    <!-- TOGGLE SIDEBAR (MOBILE) -->
    <button class="btn btn-primary d-md-none" id="btnSidebar">
        <i class="fa fa-bars"></i>
    </button>

    <!-- BRAND (CENTER ON MOBILE) -->
    <div class="brand-title nav-center fw-bold d-flex align-items-center gap-2">

        <?php if ($logo_toko && file_exists('../upload/logo/' . $logo_toko)): ?>
            <img src="../upload/logo/<?= htmlspecialchars($logo_toko) ?>"
                 alt="Logo"
                 style="height:36px; width:auto; border-radius:6px;">
        <?php else: ?>
            <i class="fa fa-print"></i>
        <?php endif; ?>

        <span class="brand-text">
            <?= htmlspecialchars($nama_toko) ?>
        </span>
    </div>

    <!-- ACTION RIGHT -->
    <div class="d-flex align-items-center gap-2">

        <!-- DARK MODE -->
        <button type="button"
                onclick="toggleDark()"
                class="btn btn-sm btn-outline-secondary dark-toggle">
            <i class="fa fa-moon"></i>
        </button>

        <!-- LANGUAGE -->
        <form action="../helpers/set_language.php"
              method="post"
              class="dropdown lang-dropdown">

            <button type="button"
                    class="btn btn-sm btn-outline-secondary dropdown-toggle lang-toggle"
                    data-bs-toggle="dropdown">
                <i class="fa fa-language"></i>
                <span class="lang-text">
                    <?= strtoupper($_SESSION['lang'] ?? 'ID') ?>
                </span>
            </button>

                <ul class="dropdown-menu dropdown-menu-end">

                    <li>
                        <button type="submit"
                                name="lang"
                                value="id"
                                class="dropdown-item d-flex align-items-center gap-2">
                            <span class="fs-5">🇮🇩</span>
                            <span>Indonesia</span>
                        </button>
                    </li>

                    <li>
                        <button type="submit"
                                name="lang"
                                value="en"
                                class="dropdown-item d-flex align-items-center gap-2">
                            <span class="fs-5">🇬🇧</span>
                            <span>English</span>
                        </button>
                    </li>

                </ul>

        </form>

        <!-- USER -->
        <?php if ($userNama): ?>
        <div class="dropdown">
            <button type="button"
                    class="btn btn-sm btn-outline-primary dropdown-toggle user-menu-toggle"
                    data-bs-toggle="dropdown">
                <i class="fa fa-user"></i>
                <span class="user-text">
                    <?= htmlspecialchars($userNama) ?>
                </span>
            </button>

            <ul class="dropdown-menu dropdown-menu-end user-menu">
                <li class="px-3 py-2">
                    <div class="fw-bold"><?= htmlspecialchars($userNama) ?></div>
                    <span class="badge bg-<?= $userRole === 'admin' ? 'success' : 'secondary' ?>">
                        <?= strtoupper($userRole) ?>
                    </span>
                </li>

                <li><hr class="dropdown-divider"></li>

                <li>
                    <a class="dropdown-item" href="pengguna.php">
                        <i class="fa fa-users me-2"></i> Pengguna
                    </a>
                </li>

                <li>
                    <a class="dropdown-item" href="setting_toko.php">
                        <i class="fa fa-cog me-2"></i> Setting
                    </a>
                </li>

                <li><hr class="dropdown-divider"></li>

                <li>
                    <a class="dropdown-item text-danger" href="../auth/logout.php">
                        <i class="fa fa-sign-out-alt me-2"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
        <?php endif; ?>

    </div>
</nav>

<!-- =========================
     CONTENT
========================= -->
<main class="flex-fill">
  <div class="container-fluid">
    <div class="row">
