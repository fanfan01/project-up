<?php
session_start(); // WAJIB

require_once 'config/database.php';

// Jika sudah login
if (isset($_SESSION['login']) && $_SESSION['login'] === true) {
    header('Location: pages/dashboard.php');
    exit;
}

// Jika belum login
header('Location: auth/login.php');
exit;
