<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "sql311.infinityfree.com";   // dari panel
$user = "if0_41078034";              // dari panel
$pass = "VanNun121900";    // password asli MySQL
$db   = "if0_41078034_db_percetakan"; // nama database lengkap

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8mb4");
?>