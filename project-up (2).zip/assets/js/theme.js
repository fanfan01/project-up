/* =====================================================
   GLOBAL CONFIG
===================================================== */
const THEME_KEY  = 'darkmode';
const DARK_CLASS = 'dark';

/* =====================================================
   DARK MODE – EARLY APPLY (ANTI FLICKER)
===================================================== */
(function () {
  try {
    if (localStorage.getItem(THEME_KEY) === 'true') {
      document.documentElement.classList.add(DARK_CLASS);
    }
  } catch (_) {}
})();

/* =====================================================
   DARK MODE TOGGLE
===================================================== */
function toggleDark() {
  const html = document.documentElement;
  const body = document.body;
  const icon = document.querySelector('.dark-toggle i');

  const isDark = !html.classList.contains(DARK_CLASS);

  html.classList.toggle(DARK_CLASS, isDark);
  body.classList.toggle(DARK_CLASS, isDark);
  localStorage.setItem(THEME_KEY, isDark);

  html.classList.add('theme-switching');
  setTimeout(() => html.classList.remove('theme-switching'), 300);

  if (icon) {
    icon.classList.toggle('fa-moon', !isDark);
    icon.classList.toggle('fa-sun', isDark);
    icon.classList.add('rotate');
    setTimeout(() => icon.classList.remove('rotate'), 300);
  }

  if (typeof window.rebuildCharts === 'function') {
    requestAnimationFrame(() => window.rebuildCharts());
  }
}

/* =====================================================
   DOM READY
===================================================== */
document.addEventListener('DOMContentLoaded', () => {

  const html      = document.documentElement;
  const body      = document.body;
  const sidebar   = document.querySelector('.sidebar');
  const overlay   = document.getElementById('sidebarOverlay');
  const btnToggle = document.getElementById('btnSidebar');
  const icon      = document.querySelector('.dark-toggle i');

  /* =========================
     APPLY DARK MODE STATE
  ========================= */
  if (localStorage.getItem(THEME_KEY) === 'true') {
    html.classList.add(DARK_CLASS);
    body.classList.add(DARK_CLASS);
    icon?.classList.replace('fa-moon', 'fa-sun');
  }

  /* =====================================================
   SIDEBAR TOGGLE (MOBILE FRIENDLY)
===================================================== */
btnToggle?.addEventListener('click', () => {
  body.classList.toggle('sidebar-open');
});

overlay?.addEventListener('click', closeSidebar);

window.addEventListener('resize', () => {
  if (window.innerWidth >= 992) closeSidebar();
});

function openSidebar() {
  document.body.classList.add('sidebar-open');
}

function closeSidebar() {
  document.body.classList.remove('sidebar-open');
}

/* =====================================================
   SIDEBAR AUTO SCROLL TO ACTIVE ITEM
===================================================== */
if (sidebar) {
  const activeItem =
    sidebar.querySelector('.submenu.active') ||
    sidebar.querySelector('.menu-item.active') ||
    sidebar.querySelector('.menu-item.parent-active');

  if (activeItem) {
    requestAnimationFrame(() => {
      sidebar.scrollTo({
        top: activeItem.offsetTop - sidebar.clientHeight / 2,
        behavior: 'smooth'
      });
    });
  }
}

  /* =========================
     SWEETALERT THEME
  ========================= */
  if (window.Swal) {
    Swal.mixin({
      customClass: {
        confirmButton: 'btn btn-primary px-4',
        cancelButton: 'btn btn-secondary px-4'
      },
      buttonsStyling: false,
      width: '420px',
      padding: '1.5rem'
    });
  }

});

/* =====================================================
   GLOBAL SWEETALERT HELPERS
===================================================== */
window.AppAlert = {

  loading(title = 'Memproses...') {
    if (!window.Swal) return;
    Swal.fire({
      title,
      allowOutsideClick: false,
      didOpen: () => Swal.showLoading()
    });
  },

  success(title = 'Berhasil', text = '', reload = true) {
    if (!window.Swal) return;
    Swal.fire({
      icon: 'success',
      title,
      text,
      timer: 1200,
      showConfirmButton: false
    }).then(() => reload && location.reload());
  },

  confirmDelete(text = 'Data tidak bisa dikembalikan') {
    if (!window.Swal) {
      return Promise.resolve({ isConfirmed: false });
    }

    return Swal.fire({
      title: 'Hapus data?',
      text,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Ya, hapus',
      cancelButtonText: 'Batal'
    });
  },

  rowDeleteAnimation(rowId) {
    const row = document.getElementById(rowId);
    if (!row) return;

    row.style.transition = 'opacity .6s ease, transform .6s ease';
    row.style.opacity = '0';
    row.style.transform = 'translateX(-12px)';
    setTimeout(() => row.remove(), 600);
  }
};

/* =====================================================
   SIDEBAR SWIPE GESTURE (MOBILE)
===================================================== */
(function () {
  let startX = 0;
  let startY = 0;
  let isSwiping = false;

  const threshold = 70;     // jarak swipe minimal
  const restraint = 80;    // toleransi scroll vertikal

  document.addEventListener('touchstart', e => {
    if (e.touches.length !== 1) return;

    const touch = e.touches[0];
    startX = touch.clientX;
    startY = touch.clientY;
    isSwiping = true;
  }, { passive: true });

  document.addEventListener('touchmove', e => {
    if (!isSwiping) return;

    const touch = e.touches[0];
    const distX = touch.clientX - startX;
    const distY = touch.clientY - startY;

    /* cegah konflik scroll */
    if (Math.abs(distY) > restraint) {
      isSwiping = false;
    }
  }, { passive: true });

  document.addEventListener('touchend', e => {
    if (!isSwiping) return;

    const touch = e.changedTouches[0];
    const distX = touch.clientX - startX;
    const distY = Math.abs(touch.clientY - startY);

    /* 👉 swipe kanan (buka sidebar) */
    if (
      distX > threshold &&
      distY < restraint &&
      !document.body.classList.contains('sidebar-open') &&
      startX < 40 // dari pinggir layar
    ) {
      openSidebar();
    }

    /* 👈 swipe kiri (tutup sidebar) */
    if (
      distX < -threshold &&
      distY < restraint &&
      document.body.classList.contains('sidebar-open')
    ) {
      closeSidebar();
    }

    isSwiping = false;
  }, { passive: true });

})();

/* =====================================================
   LOGO PREVIEW (UPLOAD)
===================================================== */
function previewLogo(input) {
  const preview = document.getElementById('logoPreview');
  if (!preview) return;

  if (input.files && input.files[0]) {
    const reader = new FileReader();

    reader.onload = e => {
      preview.src = e.target.result;
      preview.style.display = 'block';

      /* efek halus biar nyatu sama UI */
      preview.style.opacity = '0';
      preview.style.transform = 'scale(.95)';

      requestAnimationFrame(() => {
        preview.style.transition = 'opacity .25s ease, transform .25s ease';
        preview.style.opacity = '1';
        preview.style.transform = 'scale(1)';
      });
    };

    reader.readAsDataURL(input.files[0]);
  }
}

let resizeTimer;
window.addEventListener('resize', () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    window.chart7?.resize();
    window.chartMonth?.resize();
  }, 120);
});
