<?php
session_start();

if (!empty($_POST['lang'])) {
    $_SESSION['lang'] = $_POST['lang'];
}

header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? '../dashboard.php'));
exit;
