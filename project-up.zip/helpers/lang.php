<?php
function __(string $key, string $default = '') {
    global $text;
    return $text[$key] ?? $default ?? $key;
}
