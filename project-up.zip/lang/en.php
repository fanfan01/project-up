<?php

return [
    'logout_message' => 'Logging out, please wait...',
    'login_success' => 'Login successful',
    'login_failed' => 'Login failed, please check your username and password',
    
    /* =========================
       SIDEBAR / MENU
    ========================= */
    'menu'        => 'Menu',
    'master_data' => 'Master Data',
    'operational' => 'Operational',
    'reports'     => 'Reports',

    'dashboard' => 'Dashboard',

    'products'         => 'Products',
    'print_products'   => 'Printing Products',
    'digital_products' => 'Digital Products',
    'categories'      => 'Kategori',

    'materials'  => 'Materials',
    'finishing'  => 'Finishing',
    'customers'  => 'Customers',

    'transactions' => 'Transactions',
    'production'   => 'Production',
    'service'      => 'Service',

];
