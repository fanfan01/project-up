<?php

return [
    'logout_message' => 'Keluar dari sistem, mohon tunggu...',
    'login_success' => 'Login berhasil',
    'login_failed' => 'Login gagal, periksa username dan password Anda',

    /* =========================
       SIDEBAR / MENU
    ========================= */
    'menu'        => 'Menu',
    'master_data' => 'Master Data',
    'operational' => 'Operasional',
    'reports'     => 'Laporan',

    'dashboard' => 'Dashboard',

    'products'         => 'Produk',
    'print_products'   => 'Produk Percetakan',
    'digital_products' => 'Produk Digital',
    'categories'      => 'Kategori',

    'materials'  => 'Bahan',
    'finishing'  => 'Finishing',
    'customers'  => 'Pelanggan',

    'transactions' => 'Transaksi',
    'production'   => 'Produksi',
    'service'      => 'Service',

];
