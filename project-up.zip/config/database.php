<?php
$conn = mysqli_connect("localhost","root","","db_percetakan");

if (!$conn) {
  die("Koneksi database gagal");
}
