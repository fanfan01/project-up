<?php
$current = basename($_SERVER['PHP_SELF']);
?>

<div class="col-md-2">
  <div class="sidebar p-3">
    <h6 class="mt-3 mb-2 text-uppercase"><?= __('menu') ?></h6>

    <!-- DASHBOARD -->
    <a href="Dashboard.php" class="menu-item <?= $current=='Dashboard.php'?'active':'' ?>">
      <i class="fa-solid fa-gauge-high me-2"></i> <?= __('dashboard') ?>
    </a>

      <!-- ======================
          MASTER DATA
      ====================== -->
      <h6 class="mt-3 mb-2 text-uppercase"><?= __('master_data') ?></h6>

      <!-- PRODUK DROPDOWN -->
      <a class="menu-item d-flex justify-content-between align-items-center
        <?= in_array($current,['produk.php','kategori.php'])?'parent-active':'' ?>"
        data-bs-toggle="collapse"
        href="#menuProduk"
        role="button"
        aria-expanded="<?= in_array($current,['produk.php','kategori.php'])?'true':'false' ?>">
        <span>
          <i class="fa-solid fa-box-open me-2"></i> <?= __('products') ?>
        </span>
        <i class="fa-solid fa-chevron-down small"></i>
      </a>

      <div class="collapse ps-4 <?= in_array($current,['produk.php','kategori.php'])?'show':'' ?>"
          id="menuProduk">

        <!-- PRODUK -->
        <a href="produk.php"
          class="menu-item submenu <?= $current=='produk.php'?'active':'' ?>">
          <i class="fa-solid fa-box me-2"></i> <?= __('products') ?>
        </a>

        <!-- KATEGORI -->
        <a href="kategori.php"
          class="menu-item submenu <?= $current=='kategori.php'?'active':'' ?>">
          <i class="fa-solid fa-layer-group me-2"></i> <?= __('categories') ?>
        </a>

      </div>

      <!-- BAHAN -->
      <a href="bahan.php" class="menu-item <?= $current=='bahan.php'?'active':'' ?>">
        <i class="fa-solid fa-cubes me-2"></i> <?= __('materials') ?>
      </a>

      <!-- FINISHING -->
      <a href="finishing.php" class="menu-item <?= $current=='finishing.php'?'active':'' ?>">
        <i class="fa-solid fa-layer-group me-2"></i> <?= __('finishing') ?>
      </a>

      <!-- PELANGGAN -->
      <a href="pelanggan.php" class="menu-item <?= $current=='pelanggan.php'?'active':'' ?>">
        <i class="fa-solid fa-user-group me-2"></i> <?= __('customers') ?>
      </a>

    <!-- ======================
         OPERASIONAL
    ====================== -->
    <h6 class="mt-3 mb-2 text-uppercase"><?= __('operational') ?></h6>

    <a href="transaksi.php" class="menu-item <?= $current=='transaksi.php'?'active':'' ?>">
      <i class="fa-solid fa-receipt me-2"></i> <?= __('transactions') ?>
    </a>

    <a href="produksi.php" class="menu-item <?= $current=='produksi.php'?'active':'' ?>">
      <i class="fa-solid fa-industry me-2"></i> <?= __('production') ?>
    </a>

    <!-- ======================
         LAPORAN
    ====================== -->
    <h6 class="mt-3 mb-2 text-uppercase"><?= __('reports') ?></h6>

    <a href="laporan.php" class="menu-item <?= $current=='laporan.php'?'active':'' ?>">
      <i class="fa-solid fa-chart-line me-2"></i> <?= __('reports') ?>
    </a>

    <hr>

  </div>
</div>

<div class="col-md-10">
  <!-- KONTEN PAGE -->

<!-- OVERLAY (DI LUAR GRID) -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>
