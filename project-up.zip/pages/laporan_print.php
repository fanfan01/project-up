<?php
include '../config/database.php';

/* FILTER */
$dari    = $_GET['dari']   ?? date('Y-m-01');
$sampai  = $_GET['sampai'] ?? date('Y-m-d');
$qSearch = $_GET['q'] ?? '';

$total = 0;

/* AMANKAN SEARCH */
$safe = mysqli_real_escape_string($conn, $qSearch);

/* QUERY */
$sql = "
  SELECT 
    t.id,
    t.kode,
    t.tanggal,
    t.status,
    t.total,
    p.nama AS customer
  FROM transaksi t
  LEFT JOIN pelanggan p ON t.pelanggan_id = p.id
  WHERE t.tanggal >= '$dari 00:00:00'
    AND t.tanggal <= '$sampai 23:59:59'
";

if ($qSearch) {
  $sql .= "
    AND (
      t.kode LIKE '%$safe%' OR
      p.nama LIKE '%$safe%' OR
      t.status LIKE '%$safe%'
    )
  ";
}

$sql .= " ORDER BY t.tanggal ASC";

$q = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Laporan Penjualan</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { font-family: Arial, sans-serif; padding:20px; }
.report-box { max-width:900px; margin:auto; }
@media print { .btn-print { display:none; } }
</style>
</head>

<body>

<div class="report-box">

<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="fw-bold">LAPORAN PENJUALAN</h4>
  <button onclick="window.print()" class="btn btn-primary btn-sm btn-print">
    Print
  </button>
</div>

<p>
  <strong>Periode:</strong>
  <?= date('d-m-Y', strtotime($dari)) ?>
  s/d
  <?= date('d-m-Y', strtotime($sampai)) ?>
</p>

<?php if($qSearch){ ?>
<p>
  <strong>Pencarian:</strong> <?= htmlspecialchars($qSearch) ?>
</p>
<?php } ?>

<table class="table table-bordered table-striped align-middle">
<thead>
<tr class="text-center">
  <th>No</th>
  <th>Kode</th>
  <th>Tanggal</th>
  <th>Customer</th>
  <th>Status</th>
  <th class="text-end">Total</th>
</tr>
</thead>

<tbody>
<?php
$no = 1;
if (mysqli_num_rows($q)) {
  while ($d = mysqli_fetch_assoc($q)) {
    $total += $d['total'];
?>
<tr>
  <td class="text-center"><?= $no++ ?></td>
  <td><?= htmlspecialchars($d['kode']) ?></td>
  <td><?= date('d-m-Y', strtotime($d['tanggal'])) ?></td>
  <td><?= htmlspecialchars($d['customer'] ?: '-') ?></td>
  <td class="text-center"><?= strtoupper($d['status']) ?></td>
  <td class="text-end">
    Rp <?= number_format($d['total'], 0, ',', '.') ?>
  </td>
</tr>
<?php } } else { ?>
<tr>
  <td colspan="6" class="text-center text-muted">
    Data tidak ditemukan
  </td>
</tr>
<?php } ?>

<tr>
  <th colspan="5" class="text-end">TOTAL</th>
  <th class="text-end">
    Rp <?= number_format($total, 0, ',', '.') ?>
  </th>
</tr>

</tbody>
</table>

<p class="text-center mt-4">
  <em>Dicetak pada <?= date('d-m-Y H:i') ?></em>
</p>

</div>

</body>
</html>
