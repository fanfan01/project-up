<?php
include '../config/database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) die("ID transaksi tidak valid");

// ================= AMBIL TRANSAKSI =================
$t = mysqli_fetch_assoc(mysqli_query($conn, "
  SELECT * FROM transaksi WHERE id='$id'
"));
if (!$t) die("Transaksi tidak ditemukan.");

// ================= DETAIL TRANSAKSI =================
$d = mysqli_query($conn, "
  SELECT td.*, p.nama_produk 
  FROM transaksi_detail td
  LEFT JOIN produk p ON td.produk_id = p.id
  WHERE td.transaksi_id='$id'
");

// ================= HITUNG ULANG TOTAL =================
// Total sebelum diskon (SUM detail)
$qTotal = mysqli_query($conn, "
  SELECT SUM(subtotal) AS total_awal
  FROM transaksi_detail
  WHERE transaksi_id='$id'
");
$rowTotal   = mysqli_fetch_assoc($qTotal);
$total_awal = (int)($rowTotal['total_awal'] ?? 0);

// Diskon dari transaksi
$diskon = (int)($t['diskon'] ?? 0);

// Total akhir (FINAL)
$totalAkhir = max(0, $total_awal - $diskon);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Invoice <?= htmlspecialchars($t['kode']) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
  font-family: 'Segoe UI', Tahoma, sans-serif;
  padding: 20px;
}
.invoice-box {
  max-width: 800px;
  margin: auto;
  border: 1px solid #ddd;
  padding: 30px;
  border-radius: 10px;
}
@media print {
  .btn-print { display: none; }
}
</style>
</head>

<body>

<div class="invoice-box">

  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0">INVOICE</h3>
    <button class="btn btn-primary btn-print" onclick="window.print()">
      Print
    </button>
  </div>

  <div class="mb-3">
    <p><strong>Kode:</strong> <?= htmlspecialchars($t['kode']) ?></p>
    <p><strong>Tanggal:</strong> <?= htmlspecialchars($t['tanggal']) ?></p>
    <p><strong>Customer:</strong> <?= htmlspecialchars($t['customer'] ?? '-') ?></p>
  </div>

  <table class="table table-bordered table-striped">
    <thead class="table-light">
      <tr>
        <th>Produk</th>
        <th class="text-center">Qty</th>
        <th class="text-end">Subtotal</th>
      </tr>
    </thead>
    <tbody>

    <?php while ($r = mysqli_fetch_assoc($d)) { ?>
      <tr>
        <td><?= htmlspecialchars($r['nama_produk']) ?></td>
        <td class="text-center"><?= $r['qty'] ?></td>
        <td class="text-end">Rp <?= number_format($r['subtotal']) ?></td>
      </tr>
    <?php } ?>

      <!-- TOTAL SEBELUM DISKON -->
      <tr>
        <th colspan="2" class="text-end">Total</th>
        <th class="text-end">
          Rp <?= number_format($total_awal) ?>
        </th>
      </tr>

      <!-- DISKON -->
      <tr>
        <th colspan="2" class="text-end">Diskon</th>
        <th class="text-end text-danger">
          - Rp <?= number_format($diskon) ?>
        </th>
      </tr>

      <!-- TOTAL AKHIR -->
      <tr>
        <th colspan="2" class="text-end fw-bold">Total Bayar</th>
        <th class="text-end fw-bold text-success">
          Rp <?= number_format($totalAkhir) ?>
        </th>
      </tr>

    </tbody>
  </table>

  <p class="text-center mt-4">
    Terima kasih atas kepercayaan Anda 🙏
  </p>

</div>

</body>
</html>
