<?php
include '../config/database.php';

$pelanggan_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$pelanggan_id){
    echo '<div class="text-danger">Pelanggan tidak ditemukan</div>';
    exit;
}


/* ======================
   AMBIL TRANSAKSI
====================== */
$qTransaksi = mysqli_query($conn, "
    SELECT *
    FROM transaksi
    WHERE pelanggan_id = $pelanggan_id
    ORDER BY id DESC
");

if(mysqli_num_rows($qTransaksi) === 0){
    echo '<div class="text-muted">Belum ada transaksi untuk pelanggan ini.</div>';
    exit;
}
?>

<?php while($t = mysqli_fetch_assoc($qTransaksi)): ?>

<?php
/* ======================
   DETAIL TRANSAKSI
====================== */
$qDetail = mysqli_query($conn, "
    SELECT 
        td.*,
        p.nama_produk,
        IFNULL(b.nama_bahan,'-') AS bahan_nama,
        IFNULL(f.nama_finishing,'-') AS finishing_nama
    FROM transaksi_detail td
    LEFT JOIN produk p ON p.id = td.produk_id
    LEFT JOIN bahan b ON b.id = td.bahan_id
    LEFT JOIN finishing f ON f.id = td.finishing_id
    WHERE td.transaksi_id = {$t['id']}
");
?>

<div class="dashboard fade-in container-fluid">
    
<div class="mb-3 p-3 border rounded">

    <div class="d-flex justify-content-between align-items-center mb-2">
        <div>
            <strong>Transaksi:</strong> <?= htmlspecialchars($t['kode']) ?><br>
            <small class="text-muted">
                Tanggal: <?= date('d/m/Y', strtotime($t['tanggal'])) ?>
            </small>
        </div>

        <!-- STATUS TRANSAKSI -->
        <span class="badge bg-<?=
            $t['status']=='order'?'secondary':
            ($t['status']=='produksi'?'warning':
            ($t['status']=='selesai'?'success':'info'))
        ?>">
            <?= strtoupper($t['status']) ?>
        </span>
    </div>

    <div class="table-responsive">
    <table class="table table-sm table-bordered align-middle mb-0">
        <thead class="table-light text-center">
            <tr>
                <th>Produk</th>
                <th>Lebar</th>
                <th>Tinggi</th>
                <th>Qty</th>
                <th>Bahan</th>
                <th>Finishing</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php while($d = mysqli_fetch_assoc($qDetail)): ?>
            <tr>
                <td><?= htmlspecialchars($d['nama_produk'] ?? '-') ?></td>
                <td class="text-center"><?= $d['lebar'] ?></td>
                <td class="text-center"><?= $d['tinggi'] ?></td>
                <td class="text-center"><?= $d['qty'] ?></td>
                <td><?= htmlspecialchars($d['bahan_nama']) ?></td>
                <td><?= htmlspecialchars($d['finishing_nama']) ?></td>
                <td class="fw-semibold text-end">
                    Rp <?= number_format($d['subtotal'],0,',','.') ?>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    </div>

</div>

<?php endwhile; ?>
