<?php
require_once '../config/database.php';
require_once '../inc/header.php';
require_once '../inc/sidebar.php';

/* =========================
   STATISTIK
========================= */
// Total order (semua status)
$qTotal = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) AS total FROM transaksi"));

// Omset hari ini (hanya yang sudah diambil)
$qOmsetToday = mysqli_fetch_assoc(mysqli_query($conn,"
  SELECT IFNULL(SUM(total),0) AS total
  FROM transaksi
  WHERE DATE(tanggal)=CURDATE()
    AND LOWER(TRIM(status))='diambil'
"));

// Dalam produksi
$qProduksi = mysqli_fetch_assoc(mysqli_query($conn,"
  SELECT COUNT(*) AS total
  FROM transaksi
  WHERE LOWER(TRIM(status))='produksi'
"));

/* =========================
   DATA GRAFIK
========================= */
// Omset 7 hari terakhir (status diambil)
$data7 = [];
$q7 = mysqli_query($conn,"
  SELECT DATE(tanggal) AS tgl, SUM(total) AS total
  FROM transaksi
  WHERE tanggal >= CURDATE() - INTERVAL 6 DAY
    AND LOWER(TRIM(status))='diambil'
  GROUP BY DATE(tanggal)
");
while($r = mysqli_fetch_assoc($q7)) $data7[] = $r;

// Omset bulan ini (status diambil)
$dataMonth = [];
$qMonth = mysqli_query($conn,"
  SELECT DATE(tanggal) AS tgl, SUM(total) AS total
  FROM transaksi
  WHERE MONTH(tanggal)=MONTH(CURDATE())
    AND YEAR(tanggal)=YEAR(CURDATE())
    AND LOWER(TRIM(status))='diambil'
  GROUP BY DATE(tanggal)
");
while($r = mysqli_fetch_assoc($qMonth)) $dataMonth[] = $r;

/* =========================
   PRODUK TERLARIS
========================= */
$produkArray = [];
$qProduk = mysqli_query($conn,"
  SELECT p.nama_produk, COUNT(d.id) AS total
  FROM transaksi_detail d
  JOIN transaksi t ON t.id=d.transaksi_id
  JOIN produk p ON p.id=d.produk_id
  WHERE LOWER(TRIM(t.status))='diambil'
  GROUP BY d.produk_id
  ORDER BY total DESC
");
while($p = mysqli_fetch_assoc($qProduk)){
    $produkArray[] = [
        'nama' => $p['nama_produk'],
        'total'=> (int)$p['total']
    ];
}

// Produk terlaris
if(count($produkArray) > 0){
    usort($produkArray, fn($a,$b)=>$b['total']<=>$a['total']);
    $bestLabel = $produkArray[0]['nama'];
    $bestQty = $produkArray[0]['total'];
    $totalProduk = array_sum(array_column($produkArray,'total'));
    $produkPersen = $totalProduk ? round(($bestQty/$totalProduk)*100) : 0;
    $legendProduk = array_slice($produkArray,0,5);
    $produkLabel = array_column($legendProduk,'nama');
    $produkData = array_column($legendProduk,'total');
}else{
    $bestLabel = '—';
    $bestQty = 0;
    $totalProduk = 0;
    $produkPersen = 0;
    $produkLabel = [];
    $produkData = [];
}
?>

<div class="container-fluid fade-in dashboard-analytics">

<h4 class="fw-bold mb-4">
  <i class="fa-solid fa-gauge-high me-1"></i> Dashboard
</h4>

<!-- ================= STAT ================= -->
<div class="row g-3 mb-4">
  <div class="col-md-4 col-12">
    <div class="card p-3 h-100">
      <small>Total Order</small>
      <h4 class="fw-bold"><?= $qTotal['total'] ?></h4>
    </div>
  </div>

  <div class="col-md-4 col-12">
    <div class="card p-3 h-100">
      <small>Omset Hari Ini</small>
      <h4 class="fw-bold text-success">
        Rp <?= number_format($qOmsetToday['total'],0,',','.') ?>
      </h4>
    </div>
  </div>

  <div class="col-md-4 col-12">
    <div class="card p-3 h-100">
      <small>Dalam Produksi</small>
      <h4 class="fw-bold text-warning"><?= $qProduksi['total'] ?></h4>
    </div>
  </div>
</div>

<!-- ================= GRAFIK ================= -->
<div class="row g-3 mb-4">
  <div class="col-md-6 col-12">
    <div class="card p-3 h-100">
      <h6 class="fw-semibold mb-2">📈 Omset 7 Hari</h6>
      <div class="chart-box"><canvas id="chart7hari"></canvas></div>
    </div>
  </div>

  <div class="col-md-6 col-12">
    <div class="card p-3 h-100">
      <h6 class="fw-semibold mb-2">📆 Omset Bulan Ini</h6>
      <div class="chart-box chart-box-md"><canvas id="chartBulan"></canvas></div>
    </div>
  </div>
</div>

<!-- ================= PRODUK TERLARIS & TRANSAKSI ================= -->
<div class="row g-3">

<!-- PRODUK TERLARIS -->
<div class="col-md-4 col-12">
  <div class="card p-3 h-100">
    <h6 class="fw-semibold mb-3">🥇 Produk Terlaris</h6>

    <div class="position-relative d-flex flex-column align-items-center">

      <!-- DONUT -->
      <div class="donut-wrapper position-relative">
        <canvas id="chartProduk"></canvas>
        <div class="donut-center text-center">
          <div class="percent"><?= $produkPersen ?>%</div>
          <small><?= htmlspecialchars($bestLabel) ?></small>
        </div>
      </div>

      <!-- LEGEND -->
      <div class="produk-legend mt-2">
        <ul id="produkLegend"></ul>
      </div>
    </div>
  </div>
</div>

<!-- TRANSAKSI TERAKHIR -->
<div class="col-md-8 col-12">
  <div class="card p-3 ">
    <h6 class="fw-semibold mb-3">🧾 Transaksi Terakhir</h6>

    <div class="table-responsive">
      <table class="table table-striped table-hover align-middle">
        <thead>
          <tr>
            <th>Kode</th>
            <th>Tanggal</th>
            <th>Total</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
        <?php
        $last=mysqli_query($conn,"SELECT * FROM transaksi ORDER BY tanggal DESC LIMIT 5");
        while($d=mysqli_fetch_assoc($last)):
        ?>
          <tr>
            <td><?= $d['kode'] ?></td>
            <td><?= date('d/m/Y',strtotime($d['tanggal'])) ?></td>
            <td class="fw-semibold">Rp <?= number_format($d['total'],0,',','.') ?></td>
            <td>
              <span class="badge bg-<?=
                $d['status']=='order'?'secondary':
                ($d['status']=='produksi'?'warning':
                ($d['status']=='selesai'?'success':'info'))
              ?>">
                <?= strtoupper($d['status']) ?>

              </span>
            </td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>


<!-- ================= JS CHART ================= -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
Chart.defaults.font.family = "'Inter', system-ui, sans-serif";
Chart.defaults.color = '#6b7280';

const raw7 = <?= json_encode($data7) ?>;
const rawM = <?= json_encode($dataMonth) ?>;
const produkLabels = <?= json_encode($produkLabel,JSON_UNESCAPED_UNICODE) ?>;
const produkData = <?= json_encode($produkData) ?>;

const rupiah = v => 'Rp ' + Number(v).toLocaleString('id-ID');
const fmt = d => d.toISOString().slice(0,10);

let chart7=null, chartMonth=null;

function lineChart(id, labels, data){
  const el=document.getElementById(id);
  if(!el) return;
  if(id==='chart7hari' && chart7) chart7.destroy();
  if(id==='chartBulan' && chartMonth) chartMonth.destroy();

  const chart=new Chart(el,{
    type:'line',
    data:{labels, datasets:[{
      data, tension:.45, fill:true, borderWidth:3,
      borderColor:'rgba(59,130,246,1)',
      backgroundColor: ctx=>{
        const g=ctx.chart.ctx.createLinearGradient(0,0,0,160);
        g.addColorStop(0,'rgba(59,130,246,.35)');
        g.addColorStop(1,'rgba(59,130,246,0)');
        return g;
      },
      pointRadius:3,
      pointHoverRadius:5,
      pointBackgroundColor:'#3b82f6'
    }]},
    options:{
      responsive:true,
      maintainAspectRatio:false,
      animation:{duration:600,easing:'easeOutQuart'},
      plugins:{legend:{display:false}, tooltip:{backgroundColor:'#111827', callbacks:{label:ctx=>rupiah(ctx.raw)}}},
      scales:{x:{grid:{display:false}},y:{grid:{color:'rgba(148,163,184,.15)'},ticks:{callback:v=>rupiah(v)}}}
    }
  });

  if(id==='chart7hari') chart7=chart;
  if(id==='chartBulan') chartMonth=chart;
}

document.addEventListener('DOMContentLoaded',()=>{
  // 7 HARI
  let l7=[],d7=[];
  for(let i=6;i>=0;i--){
    let d=new Date(); d.setDate(d.getDate()-i);
    let f=raw7.find(x=>x.tgl===fmt(d));
    l7.push(d.toLocaleDateString('id-ID',{day:'2-digit',month:'short'}));
    d7.push(f?+f.total:0);
  }
  lineChart('chart7hari',l7,d7);

  // BULAN
  let lm=[],dm=[];
  const now=new Date();
  const days=new Date(now.getFullYear(),now.getMonth()+1,0).getDate();
  for(let i=1;i<=days;i++){
    let d=new Date(now.getFullYear(),now.getMonth(),i);
    let f=rawM.find(x=>x.tgl===fmt(d));
    lm.push(i);
    dm.push(f?+f.total:0);
  }
  lineChart('chartBulan',lm,dm);

  // DONUT PRODUK
  if(produkLabels.length){
    const colors=['#3b82f6','#60a5fa','#93c5fd','#bfdbfe','#dbeafe'];
    const totalQty=produkData.reduce((a,b)=>a+b,0);

    new Chart(document.getElementById('chartProduk'),{
      type:'doughnut',
      data:{labels:produkLabels,datasets:[{data:produkData,borderWidth:0,hoverOffset:8,backgroundColor:colors}]},
      options:{
        cutout:'72%',
        plugins:{
          legend:{display:false},
          tooltip:{backgroundColor:'#111827',
            callbacks:{label:ctx=>{ const persen=totalQty?Math.round(ctx.raw/totalQty*100):0; return `${ctx.label}: ${ctx.raw} (${persen}%)`; }}
          }
        }
      }
    });

    // UPDATE CENTER TEXT
    const centerPercentEl=document.querySelector('.donut-center .percent');
    const centerLabelEl=document.querySelector('.donut-center small');
    const bestQty=Math.max(...produkData);
    const bestIndex=produkData.indexOf(bestQty);
    const bestLabel=produkLabels[bestIndex]||'—';
    const bestPercent=totalQty?Math.round(bestQty/totalQty*100):0;
    if(centerPercentEl) centerPercentEl.textContent=bestPercent+'%';
    if(centerLabelEl) centerLabelEl.textContent=bestLabel;

    // LEGEND MAX 4 EXCLUDE TERBAIK
    const legendBox=document.getElementById('produkLegend');
    if(legendBox){
      legendBox.innerHTML='';
      const produkArrayJS=produkLabels.map((label,i)=>{
        const qty=produkData[i];
        const persen=totalQty?Math.round(qty/totalQty*100):0;
        return {label,qty,persen,color:colors[i]};
      });

      const bestQty=Math.max(...produkArrayJS.map(p=>p.qty));
      const filteredProduk=produkArrayJS
        .filter(p=>p.qty !== bestQty)  // exclude produk terbaik
        .slice(0,4);                   // ambil maksimal 4 produk

      filteredProduk.forEach((item,i)=>{
        legendBox.innerHTML+=`
          <li class="${i===0?'fw-semibold':''}">
            <span class="color" style="background:${item.color}"></span>
            <span class="label">${item.label}</span>
            <span class="qty">${item.qty}</span>
            <span class="percent">${item.persen}%</span>
          </li>
        `;
      });
    }
      }
});
</script>

<?php include '../inc/footer.php'; ?>
