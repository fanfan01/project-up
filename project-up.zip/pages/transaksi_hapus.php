<?php
include '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['id'])) {
  echo 'Invalid request';
  exit;
}

$id = (int)$_POST['id'];
if ($id <= 0) {
  echo 'ID tidak valid';
  exit;
}

$conn->begin_transaction();

try {

  // Hapus detail
  $stmtDetail = $conn->prepare(
    "DELETE FROM transaksi_detail WHERE transaksi_id = ?"
  );
  $stmtDetail->bind_param("i", $id);
  $stmtDetail->execute();

  // Hapus transaksi
  $stmtTransaksi = $conn->prepare(
    "DELETE FROM transaksi WHERE id = ?"
  );
  $stmtTransaksi->bind_param("i", $id);
  $stmtTransaksi->execute();

  // Pastikan transaksi benar-benar terhapus
  if ($stmtTransaksi->affected_rows <= 0) {
    throw new Exception('Transaksi tidak ditemukan');
  }

  $conn->commit();
  echo 'success';

} catch (Exception $e) {

  $conn->rollback();
  echo 'Error: ' . $e->getMessage();

}
exit;
