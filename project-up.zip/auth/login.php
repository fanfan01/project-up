<?php
session_start();
include '../config/database.php';

/* =========================
   SET LANGUAGE (LOGIN PAGE)
========================= */
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

/* =========================
   LOAD BAHASA
========================= */
$lang = $_SESSION['lang'] ?? 'id';
$langFile = __DIR__ . "/../lang/$lang.php";
$text = file_exists($langFile)
    ? include $langFile
    : include __DIR__ . "/../lang/id.php";

/* =========================
   HELPER
========================= */
include '../helpers/lang.php';

/* =========================
   AMBIL NAMA TOKO
========================= */
$q = mysqli_query($conn, "SELECT nama_toko FROM setting_toko LIMIT 1");
$toko = mysqli_fetch_assoc($q);
$nama_toko = $toko ? $toko['nama_toko'] : __('app_name');
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login | <?= htmlspecialchars($nama_toko) ?></title>

<script>
(function () {
  try {
    if (localStorage.getItem('darkmode') === 'true') {
      document.documentElement.classList.add('dark');
      document.body && document.body.classList.add('dark');
    }
  } catch (e) {}
})();
</script>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="../assets/css/theme.css" rel="stylesheet">
</head>

<body class="auth-page">

  <div class="auth-wrapper">

    <div class="login-card card">

      <div class="text-center mb-4">
        <h2 class="fw-bold brand-title mb-1">
          <?= htmlspecialchars($nama_toko) ?>
        </h2>
        <small class="text-muted">Login Sistem</small>
      </div>

      <form action="login_proses.php" method="post">

        <div class="mb-3 input-group">
          <span class="input-group-text bg-primary text-white">
            <i class="fa fa-user"></i>
          </span>
          <input
            type="text"
            name="username"
            class="form-control"
            placeholder="Username"
            required>
        </div>

        <div class="mb-3 input-group">
          <span class="input-group-text bg-primary text-white">
            <i class="fa fa-lock"></i>
          </span>
          <input
            type="password"
            name="password"
            class="form-control"
            placeholder="Password"
            required>
        </div>

        <button type="submit" class="btn btn-primary w-100 mb-3">
          <i class="fa fa-sign-in-alt me-2"></i> Login
        </button>

      </form>

      <div class="text-center">
        <button
          type="button"
          onclick="toggleDark()"
          class="btn btn-outline-secondary btn-sm dark-toggle">
          <i class="fa fa-moon"></i>
        </button>
      </div>

    </div>

  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/theme.js"></script>
</body>
</html>
